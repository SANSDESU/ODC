$(document).ready(function() {
    $('#major-input').on('change', function() {
        updateCategoryItems();
    });

    function updateCategoryItems() {

        var selectedMajor = $('#major-input').val();
        $.ajax({
            type: 'POST',
            url: '../php/fetch_category.php', // Replace with your PHP script
            data: { major: selectedMajor , category:userSkill},
            dataType: 'html',
            success: function(response) {
                $('.category-container').html(response);

                // Initialize Choices for category select
                var categorySelect = new Choices('#choices-multiple-remove-button', {
                    removeItemButton: true
                });
            },
            error: function() {
                $('.category-container').html('Error loading categories.');
            }
        });
    }

    // Initial setup
    updateCategoryItems();
});