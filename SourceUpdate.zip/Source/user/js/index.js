$(document).ready(function() {
    $('#major-input').on('change', function() {
        updateCategoryItems();
    });

    function updateCategoryItems() {

        var selectedMajor = $('#major-input').val();

        $.ajax({
            type: 'POST',
            url: '../php/fetch_category.php', // Replace with your PHP script
            data: { major: selectedMajor , category:userSkill},
            dataType: 'html',
            success: function(response) {
                $('.category-container').html(response);

                // Initialize Choices for category select
                var categorySelect = new Choices('#choices-multiple-remove-button', {
                    removeItemButton: true
                });
            },
            error: function() {
                $('.category-container').html('Error loading categories.');
            }
        });
    }

    // Initial setup
    updateCategoryItems();
});

$(document).ready(function() {

    var $form = $('#form-profil');

    //$form.validate();

    $form.on( "submit", function(e) {

        var categoryValue = categorys().replace(", ", ",");
        var newpass = passUser();
        var major = $('#major-input :selected').text();
        //var img = $('#imageInput');
        var dataString = $(this).serializeArray();

        //alert(dataString);
        //alert("Pass:"+passUser());
        //alert("Category:"+categoryValue);

        //alert(dataString+"Pass: "+passUser()+"Category: "+categoryValue);
        //return false;



        $.ajax({
            type: "POST",
            url: "../php/update-data-siswa.php",
            data: { dataString, major:major, pass:newpass, category:categoryValue},
            success: function (response) {
                //alert(response);
                if (response == 'success'){
                    swal(7,'Perubahan Telah Disimpan');
                    location. reload();
                }
                //$('#bio-input').val(response);


            }
        });

        e.preventDefault();

    });

    function passUser(){
        var oldpass = $('#old-pass-input').val();
        var newpass = $('#new-pass-input').val();

        if (oldpass == newpass){
            return newpass;
        } else {
            return('no_change');
        }
    }

});

function getDataFromRow(rowElement) {
    var tdValues = [];

    $(rowElement).find('td').each(function() {
        var tdValue = $(this).text().trim();
        tdValues.push(tdValue);
    });

    return tdValues;
}

function getCurrentIndex(buttonElement, option) {
    var rowElement = $(buttonElement).closest('tr')[0];
    var dataIndex = $(rowElement).index();

    var rowData = getDataFromRow(rowElement);

    if (option == "view"){
        lihat(dataIndex+1);
    }
    else if (option == "edit"){
        alert(rowData);

    } else if (option == "delete"){
        Swal.fire({
            title: 'Hapus '+rowData[2]+'?',
            text: "Anda tidak bisa mengembalikan file yang dihapus!",
            icon: 'warning',
            showCancelButton: true,
            showConfirmButton: true,
            confirmButtonColor: '#FA8B91',
            cancelButtonColor: '#6ABB5F',
            cancelButtonText: 'Batal',
            confirmButtonText: 'Hapus'
          }).then((result) => {
            if (result.isConfirmed) {

                $.ajax({
                    type: 'POST',
                    url: '../php/deleteDat.php', // Replace with your PHP script
                    data: { table: 'db_sertifikat' , id:rowData[1]},
                    dataType: 'html',
                    success: function(response) {
                        location. reload();
                    },
                    error: function() {
                        console.log('err');
                    }
                });

              }
          })

    } else if (option == "alert"){
        alert(rowData);
    } else {
        return {
            index: dataIndex,
            data: rowData
        };
    }

}

const body = document.querySelector('body'),
    sidebar = body.querySelector('nav'),
    toggle = body.querySelector(".toggle"),
    searchBtn = body.querySelector(".search-box"),
    modeSwitch = body.querySelector(".toggle-switch"),
    modeText = body.querySelector(".mode-text");


toggle.addEventListener("click", () => {
    sidebar.classList.toggle("close");
})

searchBtn.addEventListener("click", () => {
    sidebar.classList.remove("close");
})

modeSwitch.addEventListener("click", () => {
    body.classList.toggle("dark");

    if (body.classList.contains("dark")) {
        modeText.innerText = "Light mode";
    } else {
        modeText.innerText = "Dark mode";

    }
});

// detect dark mode
if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    modeSwitch.click();
}

function menu(id, menu) {
    element = document.getElementById('_dashboard-container');
    title_text = document.getElementById('title-text');
    view = document.getElementById(id);
    dash = document.getElementById("dashboard");
    profile = document.getElementById("profil");
    notif = document.getElementById("sertifikat");

    var delayInMilliseconds = 100; //1 second

    if (view.style.display != 'block') {
        element.classList.remove("show");
        element.classList.add("hide");

        setTimeout(function() {
            dash.style.display = 'none';
            profile.style.display = 'none';
            notif.style.display = 'none';

            view.style.display = 'block';
            title_text.innerHTML = menu;

            element.classList.remove("hide");
            element.classList.add("show");
        }, delayInMilliseconds);
      }
}

function categorys(){
    var selectElement = document.getElementById('choices-multiple-remove-button');
    // var choicesInstance = new Choices(selectElement, {
    //     removeItemButton: true,
    //     // Other options...
    // });

    var selectedValues = Array.from(selectElement.selectedOptions).map(option => option.value);

        // Display the selected values using an alert
        if (selectedValues.length > 0) {
            return selectedValues.join(', ');
        } else {
            return 'No values selected.';
        }
}

// document.addEventListener('DOMContentLoaded', function() {
//     var selectElement = document.getElementById('choices-multiple-remove-button');
//     var choicesInstance = new Choices(selectElement, {
//         removeItemButton: true,
//         // Other options...
//     });

//     var showSelectedButton = document.getElementById('showSelectedButton');
//     showSelectedButton.addEventListener('click', function() {
//         var selectedValues = Array.from(selectElement.selectedOptions).map(option => option.value);

//         // Display the selected values using an alert
//         if (selectedValues.length > 0) {
//             alert('Selected values: ' + selectedValues.join(', '));
//         } else {
//             alert('No values selected.');
//         }
//     });
// });

 document.getElementById('change-profile-image').addEventListener("click", () => {
    var token = document.getElementById('change-profile-image').getAttribute('token');
    upPfp(token);
     //document.getElementById('imageInput').click()
 })

 document.getElementById('up_serti').addEventListener("click", () => {
    var token = document.getElementById('up_serti').getAttribute('token');
    upDoc(token);
     //document.getElementById('imageInput').click()
 })

function copy_link(){
    document.getElementById('social_input');
    social_input.select();
    document.execCommand('copy');
    swal(7,'Copied!');
}

function openModal() {
    document.getElementById("docView").style.display = "block";
  }

  function closeModal() {
    fadeInOut("docView", 0);
    setTimeout(function() {
        document.getElementById("docView").style.display = "none";
    }, 100);

  }

  var slideIndex = 1;
  showSlides(slideIndex);

  function plusSlides(n) {
    showSlides(slideIndex += n);
  }

  function currentSlide(n) {
    showSlides(slideIndex = n);
  }

  function showSlides(n) {
    var i;
    var slides = document.getElementsByClassName("docSlides");
    var dots = document.getElementsByClassName("demo");
    var captionText = document.getElementById("caption");
    var numText = document.getElementById("numText");
    if (n > slides.length) {slideIndex = 1}
    if (n < 1) {slideIndex = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" _active", "");
    }
    slides[slideIndex-1].style.display = "block";
    dots[slideIndex-1].className += " _active";
    captionText.innerHTML = dots[slideIndex-1].alt;
    numText.innerHTML = slideIndex+"/"+slides.length;
  }

  function fadeInOut(id, option){
    view = document.getElementById(id);

    if (option == 1){
        view.classList.remove("modal-hide");
        view.classList.add("modal-show");

    } else {
        view.classList.remove("modal-show");
        view.classList.add("modal-hide");
    }

  }

function lihat(cs){
    openModal();
    currentSlide(cs);
    fadeInOut('docView', 1);
}

function upDoc(token){

    title_content =
    '<form class="container rounded bg p-3" style="overflow: hidden;" enctype="multipart/form-data" action="" method="POST">'+

    '<div class="row d-flex justify-content-center align-content-center border-bottom mb-2 pb-1">'+
    '<div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Upload Sertifikat</span>'+
    '</div></div>'+
    '<div class="row d-flex justify-content-center align-content-center">';

    html_content =
        '<div class="col-md-12"><label class="labels">Nama Sertifikat</label><input type="text"'+
            'class="form-control" placeholder="Masukkan Nama Serifikat"'+
            'value="" name="file-title">'+
        '</div>'+

        '<div class="col-md-12"><label class="labels">Tanggal Diperoleh</label>'+
            '<input type="date" class="form-control" name="file-date" style=" float:left;">'+
        '</div>'+

        '<div class="col-md-12"><label class="labels">Gambar Sertifikat</label>'+
            '<input type="file" accept="image/*" class="form-control" name="uploaded" style=" float:left;">'+
        '</div>'+
        '<input type="text" name="_token"  value="'+token+'" />';

    footer_content =
        '<div class="w-100 mt-3 d-flex justify-content-around">'+
            '<button class="btn btn-primary profile-button mr-3" type="submit" name="Upload">Upload</button>'+
            '<button class="btn btn-primary profile-button red-filter" type="button" onclick="Swal.close()">Batal</button>'+
        '</div>'+
        '</div></form>';

    Swal.fire({
        background: 'transparent',
        customClass: 'swal-rmv-padding',
        html: title_content+html_content+footer_content ,
        showDenyButton: false,
        showCancelButton: false,
        showConfirmButton: false,
      })
}



function upPfp(token){

    title_content =
    '<form class="container rounded bg p-3" style="overflow: hidden;" enctype="multipart/form-data" action="" method="POST">'+

    '<div class="row d-flex justify-content-center align-content-center border-bottom mb-2 pb-1">'+
    '<div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Upload Foto Profil</span>'+
    '</div></div>'+
    '<div class="row d-flex justify-content-center align-content-center">';

    html_content =
        '<div class="col-md-12 d-flex justify-content-center align-content-center">'+
        '<img style="display:none;" id="pfp" class="rounded-circle mt-3" height="200px" width="200px" src="" alt="profile">'+
        '</div>'+

        '<div class="col-md-12 center"><label class="labels">Pilih Gambar</label>'+
            `<input id="imageInput" name="pfpupload" type="file" accept="image/*" onchange="pfp = document.getElementById('pfp'); pfp.src = window.URL.createObjectURL(this.files[0]); pfp.style.display = 'block';" />`+
        '</div>';

    footer_content =
        '<div class="w-100 mt-3 d-flex justify-content-around">'+
            '<button class="btn btn-primary profile-button mr-3" type="submit" name="UploadPFP">Upload</button>'+
            '<button class="btn btn-primary profile-button red-filter" type="button" onclick="Swal.close()">Batal</button>'+
        '</div>'+
        '</div></form>';

    Swal.fire({
        background: 'transparent',
        customClass: 'swal-rmv-padding',
        html: title_content+html_content+footer_content ,
        showDenyButton: false,
        showCancelButton: false,
        showConfirmButton: false,
      })
}