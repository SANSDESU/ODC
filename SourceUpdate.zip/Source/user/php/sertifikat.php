<div id="sertifikat" style="display: none;">
                    <div class="container rounded ">
                        <div class="row">

                            <div class="col-sm-8 mr-3 mb-3">
                                <div class="row">
                                    <div class="col-12 rounded shadow bg pb-2 pt-2">
                                        <div class="d-flex justify-content-center align-items-center">
                                            <div class="container" id="list_content">
                                                <div class="mb-2 d-flex justify-content-between align-items-center"
                                                    style="font-size: 15px;">

                                                    <div class="position-relative align-items-center mt-2 mb-2 bg">
                                                        <span class="position-absolute search"><i
                                                                class="fa fa-search"></i></span>
                                                        <input class="form-control w-100" style="padding-left:32px;"
                                                            placeholder="Search by order#, name...">
                                                    </div>

                                                    <div class="px-2">
                                                        <span>Filters <i class="fa fa-angle-down"></i></span>
                                                        <i class="fa fa-ellipsis-h ms-3"></i>
                                                    </div>

                                                </div>
                                                <div class="table-responsive">
                                                    <table class="table table-responsive table-borderless text"
                                                        style="font-size: 15px; color: var(--text-color);">
                                                        <thead>
                                                            <tr class="bg">
                                                                <th scope="col" width="5%">No</th>
                                                                <th scope="col" width="5%">Id</th>
                                                                <th scope="col" width="20%">Nama Sertifikat</th>
                                                                <th scope="col" width="20%">Tanggal Diperoleh</th>
                                                                <th scope="col" width="20%">Tanggal Diupload</th>
                                                                <th scope="col" class="text-end" width="20%">
                                                                    <span>Aksi</span></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php fotoSerti(1); ?>

                                                        </tbody>
                                                    </table>
                                                </div>

                                                <div id="docView" class="modal modal-opacity">
                                                    <div class="d-flex justify-content-center align-items-center">
                                                        <span class="_close pointer"
                                                            onclick="closeModal()">&times;</span>
                                                        <div class="modal-content">
                                                            <div
                                                                class="d-flex justify-content-center align-items-center">
                                                                <div id="numText" class="numbertext rounded"></div>
                                                            </div>

                                                            <div
                                                                class="d-flex justify-content-center align-items-center">

                                                                <?php fotoSerti(2); ?>


                                                            </div>

                                                            <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                                                            <a class="next" onclick="plusSlides(1)">&#10095;</a>

                                                            <div
                                                                class="d-flex justify-content-center align-items-center mt-2 md-2">
                                                                <p id="caption" style="color:#ccc"></p>
                                                            </div>

                                                            <div class="row overflow-auto hide-scroll"
                                                                style="background-color: transparent;">

                                                                <?php fotoSerti(3); ?>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="row">
                                    <div class="col-12 rounded shadow bg mb-3 pb-2">
                                        <!--div class="d-flex align-items-center justify-content-between border-bottom" profile</div-->
                                        <div
                                            class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                            <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn"
                                                    style="font-size: 20px;">Menu</span></div>

                                        </div>

                                        <div class="row p-3">
                                            <button class="btn btn-primary profile-button" type="button"
                                               token="<?php echo $_SESSION['_token']; ?>" id="up_serti">Upload Sertifikat</button>

                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>


                    </div>
                </div>