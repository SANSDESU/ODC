                <div id="dashboard" style="display: none;">
                    <div class="container mt-3 mb-3">
                        <div class="row">

                            <div class="col-sm-5 mb-3 mr-3">
                                <div class="row">
                                    <div class="col-12 rounded shadow bg mb-3 pb-3">

                                        <div class="d-flex flex-column align-items-center text-center">
                                            <?php fotoProfil(2); ?>
                                            <div class="text logo-text">
                                                <span class="name font-weight-bold" id="full-name-1"></span>
                                            </div>
                                            <span class="text text-muted" style="font-size: 15px;" id="bio"></span>
                                            <div class="d-flex">
                                                <div class="input-text">
                                                    <input style="padding-left: 10px;" class="tag-bg text-muted"
                                                        type="text" id="social_input"
                                                        value="https://bkksoji.site/profil/?user=surya">
                                                    <i class="fa fa-copy" id="copy" onclick="copy_link();"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 rounded shadow bg pb-2">

                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 15px;">
                                            <i class="bx bxl-whatsapp text-muted" aria-hidden="true"><span
                                                    class="font-weight-bold text-muted"
                                                    style="margin-left: 5px; font-size: 15px;">WhatsApp</span></i>
                                            <?php urlWA(); ?>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 15px;">
                                            <i class="bx bx-link text-muted" aria-hidden="true"><span
                                                    class="font-weight-bold text-muted"
                                                    style="margin-left: 5px; font-size: 15px;">Website</span></i>
                                            <a class="a" href="#" style="font-size: 15px;">website-link</a>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 15px;">
                                            <i class="bx bxl-github text-muted" aria-hidden="true"><span
                                                    class="font-weight-bold text-muted"
                                                    style="margin-left: 5px; font-size: 15px;">Github</span></i>
                                            <a class="a" href="#" style="font-size: 15px;">github-link</a>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 15px;">
                                            <i class="bx bxl-linkedin-square text-muted" aria-hidden="true"><span
                                                    class="font-weight-bold text-muted"
                                                    style="margin-left: 5px; font-size: 15px;">Linkedin</span></i>
                                            <a class="a" href="#" style="font-size: 15px;">linkedin-link</a>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 15px;">
                                            <i class="bx bxl-instagram text-muted" aria-hidden="true"><span
                                                    class="font-weight-bold text-muted"
                                                    style="margin-left: 5px; font-size: 15px;">Instagram</span></i>
                                            <a class="a" href="#" style="font-size: 15px;">instagram-link</a>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 15px;">
                                            <i class="bx bxl-youtube text-muted" aria-hidden="true"><span
                                                    class="font-weight-bold text-muted"
                                                    style="margin-left: 5px; font-size: 15px;">Youtube</span></i>
                                            <a class="a" href="#" style="font-size: 15px;">youtube-link</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="row">
                                    <div class="col-12 rounded shadow bg mb-3 pb-3">
                                        <div
                                            class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                            <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn"
                                                    style="font-size: 20px;">Detail Profil</span></div>

                                        </div>

                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 15px;">
                                            <span class="font-weight-bold text-muted" style="font-size: 15px;">Nama
                                                Lengkap</span>
                                            <span class="font-weight-normal text-muted" style="font-size: 15px;"
                                                id="full-name-2"></span>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 15px;">
                                            <span class="font-weight-bold text-muted" style="font-size: 15px;">Tanggal
                                                Lahir</span>
                                            <span class="font-weight-normal text-muted" style="font-size: 15px;"
                                                id="date"></span>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 15px;">
                                            <span class="font-weight-bold text-muted"
                                                style="font-size: 15px;">Umur</span>
                                            <span class="font-weight-normal text-muted" style="font-size: 15px;"
                                                id="age"></span>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 15px;">
                                            <span class="font-weight-bold text-muted" style="font-size: 15px;">Asal
                                                Sekolah</span>
                                            <span class="font-weight-normal text-muted" style="font-size: 15px;"
                                                id="school"></span>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 15px;">
                                            <span class="font-weight-bold text-muted" style="font-size: 15px;">Tahun
                                                Lulus</span>
                                            <span class="font-weight-normal text-muted" style="font-size: 15px;"
                                                id="graduate"></span>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 15px;">
                                            <span class="font-weight-bold text-muted" style="font-size: 15px;">Jurusan
                                            </span>
                                            <span class="font-weight-normal text-muted" style="font-size: 15px;"
                                                id="major"></span>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 15px;">
                                            <span class="font-weight-bold text-muted" style="font-size: 15px;">Status
                                                Pekerjaan</span>
                                            <span class="font-weight-normal text-muted" style="font-size: 15px;"
                                                id="work-status"></span>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 15px;">
                                            <span class="font-weight-bold text-muted"
                                                style="font-size: 15px;">Alamat</span>
                                            <span class="font-weight-normal text-muted" style="font-size: 15px;"
                                                id="address"></span>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 15px;">
                                            <span class="font-weight-bold text-muted" style="font-size: 15px;">No
                                                Handphone</span>
                                            <span class="font-weight-normal text-muted" style="font-size: 15px;"
                                                id="mobile-number"></span>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 15px;">
                                            <span class="font-weight-bold text-muted"
                                                style="font-size: 15px;">Email</span>
                                            <span class="font-weight-normal text-muted" style="font-size: 15px;"
                                                id="email"></span>
                                        </div>


                                    </div>
                                    <div class="col-12 rounded shadow bg pb-2">

                                        <div
                                            class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                            <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn"
                                                    style="font-size: 20px;">Skill</span></div>

                                        </div>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="bg align-items-start w-100 overflow-auto hide-scroll">
                                                <!--height: max-content; margin-left: 20px; margin-right: 20px;-->
                                                <?php skill(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>