
                <div id="profil" style="display: none;">
                    <form class="container mt-3 mb-3" id="form-profil" action="" method="POST">
                        <div class="row">

                            <div class="col-sm-3 mr-3" >
                                <div class="row">
                                    <div class="col-12 rounded shadow bg mb-3 d-flex flex-column align-items-center text-center p-3 py-5">


                                    <?php fotoProfil(3); ?>
                                    <!--i class='bx bxs-pencil topright' onclick="pickImage();" style="cursor: pointer;"></i-->
                                    <button class="btn btn-primary pickImageBtn w-50" type="button"
                                        id="change-profile-image" token="<?php echo $_SESSION['_token']; ?>">Ubah Foto Profil</button>
                                    <button class="btn btn-primary pickImageBtn mb-5 blue-filter w-50" type="button"
                                        id="edit-social-media">Edit Sosial Media</button>

                                    <!--span class="font-weight-bold" id="name-text">Surya</span-->
                                    <label class="labels mb-2">Bio [max:150 char]</label>
                                    <textarea class="form-control hide-scroll h-100" name="bio" id="bio-input"
                                        placeholder="Masukkan Bio" rows="7" cols="50" maxlength="150"
                                        style="resize:none" value=""></textarea>

                                    </div>

                                </div>
                            </div>

                            <div class="col-sm-5 mr-3">
                                <div class="row">
                                    <div class="col-12 rounded shadow bg mb-3 pb-3">

                                        <div
                                            class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                            <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn"
                                                    style="font-size: 20px;">Pengaturan Profil</span></div>

                                        </div>
                                        <div class="row">
                                            <div class="col-md-6"><label class="labels">Nama Depan</label><input type="text"
                                                    class="form-control" placeholder="Nama Depan" value=""
                                                    name="username" id="username-input" required></div>
                                            <div class="col-md-6"><label class="labels">Nama Belakang</label><input
                                                    type="text" class="form-control" value="" placeholder="Nama Belakang"
                                                    name="surname" id="surname-input" required></div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6"><label class="labels">Password Lama</label><input
                                                    type="password" class="form-control"
                                                    placeholder="Masukkan Password Lama" value="" id="old-pass-input"></div>
                                            <div class="col-md-6"><label class="labels">Password Baru</label><input
                                                    type="password" class="form-control"
                                                    placeholder="Masukkan Password Baru" value="" id="new-pass-input"></div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-12"><label class="labels">Email Pribadi</label><input
                                                    type="text" class="form-control" value=""
                                                    placeholder="Masukkan Email Pribadi" name="email" id="email-input" required>
                                            </div>
                                            <div class="col-md-12"><label class="labels">Alamat</label><input type="text"
                                                    class="form-control" placeholder="Masukkan Alamat Tempat Tinggal"
                                                    value="" name="address" id="address-input" required></div>
                                            <div class="col-md-12"><label class="labels">Asal Sekolah</label><input
                                                    type="text" class="form-control" placeholder="Masukkan Asal Sekolah"
                                                    value="" name="school" id="school-input" required></div>

                                        </div>
                                        <div class="mt-3 text-center"><button class="btn btn-primary profile-button"
                                                type="submit" name="submit"
                                                id="save-profile">Simpan Perubahan</button></div>

                                    </div>

                                </div>
                            </div>

                            <div class="col-sm-3">
                                <div class="row">
                                    <div class="col-12 rounded shadow bg mb-3 pb-3">

                                        <div
                                            class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                            <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn"
                                                    style="font-size: 20px;">Data Diri</span></div>

                                        </div>

                                        <div class="row">
                                            <div class="col-md-6"><label class="labels">Tanggal lahir</label>
                                                <input type="date" class="form-control" name="date" id="date-input" style=" float:left;"
                                                    onchange="" required>
                                            </div>

                                            <div class="col-md-6"><label class="labels">Tahun Lulus</label><input
                                                    type="number" class="form-control" value=""
                                                    placeholder="Masukkan Tahun Lulus" name="graduate" id="graduate-input" required></div>

                                            <div class="col-md-6" style="display: none;"><label class="labels">Umur</label><input type="number"
                                                    class="form-control" value="" placeholder="umur" name="age" id="age-input"></div>
                                        </div>
                                        <div class="row">

                                            <div class="col-md-6"><label class="labels">Nomor Handphone</label><input
                                                    type="number" class="form-control" value="" placeholder="Masukkan No HP"
                                                    name="phone" id="mobile-number-input" required></div>
                                            <div class="col-md-6"><label class="labels">Status Pekerjaan</label>
                                                <select class="form-control" name="work" id="work-status-input" required>
                                                    <option value="Belum Bekerja">Belum Bekerja</option>
                                                    <option value="Bekerja">Bekerja</option>
                                                </select>
                                            </div>
                                        </div>

                                    </div>

                                </div>

                                <div class="row">
                                    <div class="col-12 rounded shadow bg pb-3">

                                    <div
                                        class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                        <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn"
                                                style="font-size: 20px;">Keahlian</span></div>

                                    </div>
                                    <div class="col-md-12">
                                        <label class="labels">Jurusan</label>
                                        <div class="rounded w-100 h-100 align-items-start">
                                            <!--height: max-content; margin-left: 20px; margin-right: 20px;-->
                                            <?php major(); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="labels">Keahlian Sesuai Jurusan</label>
                                        <div class="category-container">
                                            <!-- Category items will be dynamically loaded here -->
                                        </div>
                                    </div>

                                    </div>

                                </div>

                            </div>


                        </div>
                    </form>
                </div>