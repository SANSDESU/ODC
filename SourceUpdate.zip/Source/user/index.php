<?php


//echo '<script>alert("'. date('F j, Y').$_SESSION['user']['nama'].'")</script>';
include_once "../php/cek-akses.php";
include "../php/db-config.php";
include "../php/image-upload.php";
include "../php/pfp-upload.php";

uploadFile('student');

function setData(){

    $pdo = include "../php/koneksi.php";
    $query = $pdo->prepare("select * from db_siswa where user_id=:user_id");
    $query->bindParam(':user_id', $_SESSION['user']['id'], PDO::PARAM_INT);
    $query->execute();
    $data = $query->fetch();

    $pdo_student = include "../php/koneksi.php";
    $query_student = $pdo_student->prepare("select nama,role from student where id=:id");
    $query_student->bindParam(':id', $_SESSION['user']['id'], PDO::PARAM_INT);
    $query_student->execute();
    $student_data = $query_student->fetch();

    $fullname = $data['nama_depan']." ".$data['nama_belakang'];
    echo '
    <script>

        /* Sidebar */
        document.getElementById("name").innerHTML = "'.$student_data['nama'].'";
        document.getElementById("role").innerHTML = "'.$student_data['role'].'";

        /* Detail */
        document.getElementById("full-name-1").innerHTML = "'.$fullname.'";
        document.getElementById("full-name-2").innerHTML = "'.$fullname.'";
        document.getElementById("bio").innerHTML = "'.$data['bio'].'";
        document.getElementById("date").innerHTML = "'.$data['tanggal_lahir'].'";
        document.getElementById("age").innerHTML = "'.$data['umur'].' Tahun";
        document.getElementById("school").innerHTML = "'.$data['asal_sekolah'].'";
        document.getElementById("graduate").innerHTML = "'.$data['tahun_lulus'].'";
        document.getElementById("major").innerHTML = "'.$data['jurusan'].'";
        document.getElementById("work-status").innerHTML = "'.$data['status_pekerjaan'].'";
        document.getElementById("address").innerHTML = "'.$data['alamat'].'";
        document.getElementById("mobile-number").innerHTML = "'.$data['no_hp'].'";
        document.getElementById("email").innerHTML = "'.$data['email'].'";

        /* Input Value */
        document.getElementById("username-input").value = "'.$data['nama_depan'].'";
        document.getElementById("surname-input").value = "'.$data['nama_belakang'].'";
        document.getElementById("bio-input").value = "'.$data['bio'].'";
        document.getElementById("date-input").value = "'.$data['tanggal_lahir'].'";
        //document.getElementById("age-input").value = "'.$data['umur'].'";
        document.getElementById("graduate-input").value = "'.$data['tahun_lulus'].'";
        document.getElementById("work-status-input").value = "'.$data['status_pekerjaan'].'";
        document.getElementById("mobile-number-input").value = "'.$data['no_hp'].'";
        document.getElementById("email-input").value = "'.$data['email'].'";
        document.getElementById("address-input").value = "'.$data['alamat'].'";
        document.getElementById("school-input").value = "'.$data['asal_sekolah'].'";

    </script>';

}

function major(){
    include "../php/db-config.php";

    $pdo = include "../php/koneksi.php";
    $query = $pdo->prepare("select jurusan from db_siswa where user_id=:user_id");
    $query->bindParam(':user_id', $_SESSION['user']['id'], PDO::PARAM_INT);
    $query->execute();
    $data = $query->fetch();

    $pdo_mjr = include "../php/koneksi.php";
    $query_mjr = $pdo_mjr->prepare("select inisial_jurusan from config where id=1");
    $query_mjr->execute();
    $data_mjr = $query_mjr->fetch();

    $savedValues = $data['jurusan'];
    $selected = "";

    $jurusan = explode(",", $config['jurusan']);
    $inisial_jurusan = explode(",", $data_mjr['inisial_jurusan']);
    $combinedArray = array_combine($jurusan, $inisial_jurusan);

    echo '<select class="form-control" id="major-input" required>';

    foreach ($combinedArray as $value => $inisial) {
        if ($value == $savedValues) {
            $selected = "selected";
        } else {
            $selected = "";
        }

        echo '<option value="'.$inisial.'"' . $selected . '>'.$value.'</option>';
    }

    echo '</select>';

}

function skillData(){
    $pdo = include "../php/koneksi.php";
    $query = $pdo->prepare("select * from db_siswa where user_id=:user_id");
    $query->bindParam(':user_id', $_SESSION['user']['id'], PDO::PARAM_INT);
    $query->execute();
    $data = $query->fetch();

    return $data['skill'];


}

function skill(){
    $skills = explode(",", skillData());
    foreach ($skills as $value) {
        echo '<span class="tag" style="margin-left: 1.5px; margin-right: 1.5px;">'.$value.'</span>';
    }

}
function varSkill(){
    $skills = skillData();

    echo '<script>var userSkill = "'.$skills.'";</script>';

}


function fotoProfil($no){
    $pdo = include "../php/koneksi.php";
    $query = $pdo->prepare("select * from db_siswa where user_id=:user_id");
    $query->bindParam(':user_id', $_SESSION['user']['id'], PDO::PARAM_INT);
    $query->execute();
    $data = $query->fetch();

    if ($no == 1){
        echo '<img src="'.host().'/foto'.$data['foto_profil'].'" alt="profile">';
    } else if ($no == 2) {
        echo '<img class="rounded-circle mt-3" height="30%" width="30%" src="'.host().'/foto'.$data['foto_profil'].'" alt="profile">';
    } else {
        echo '<img class="rounded-circle mt-3" height="70%" width="70%" src="'.host().'/foto'.$data['foto_profil'].'" alt="profile">';
    }

}

function fotoSerti($no){
    $pdo = include "../php/koneksi.php";
    $query = $pdo->prepare("select * from db_sertifikat where user_id=:user_id");
    $query->bindParam(':user_id', $_SESSION['user']['id'], PDO::PARAM_INT);
    $query->execute();
    $rows = $query->fetchAll(PDO::FETCH_ASSOC);
    $view = "'view'";
    $delete = "'delete'";
    $counter = 0;

    foreach ($rows as $data){
        $counter += 1;
        // 1
        if ($no == 1){
            echo '
            <tr>
                <td>'.$counter.'</td>
                <td>'.$data['id'].'</td>
                <td>'.$data['nama_sertifikat'].'</td>
                <td>'.$data['tanggal_diperoleh'].'</td>
                <td>'.$data['tanggal_diupload'].'</td>
                <td class="text-end">
                    <button class="btn btn-primary pickImageBtn blue-filter" type="button"
                        id="view-doc"
                        onclick="getCurrentIndex(this,'.$view.')">Lihat</button>
                    <button class="btn btn-primary pickImageBtn" type="button"
                        id="edit-doc">Edit</button>
                    <button class="btn btn-primary pickImageBtn red-filter" type="button"
                        id="delete-doc" onclick="getCurrentIndex(this,'.$delete.')">Hapus</button>
                </td>
            </tr>
            ';
        }

        // 2
        else if ($no == 2){
            echo '
            <div class="docSlides">
                <img class="imgs rounded"
                    src="'.host().'/foto'.$data['foto_sertifikat'].'">
            </div>
            ';
        }

        // 2
        else if ($no == 3){
            echo '
            <div class="col" style="height: 100px; width: 200px; max-width: 200px;">
                <img class="demo pointer rounded w-100 h-100"
                    src="'.host().'/foto'.$data['foto_sertifikat'].'"
                    onclick="currentSlide('.$counter.')" alt="'.$data['nama_sertifikat'].'">
            </div>
            ';
        }

    }
}

function urlWA(){
    $pdo = include "../php/koneksi.php";
    $query = $pdo->prepare("select * from db_siswa where user_id=:user_id");
    $query->bindParam(':user_id', $_SESSION['user']['id'], PDO::PARAM_INT);
    $query->execute();
    $data = $query->fetch();

    echo '<a class="a" href="https://wa.me/62'.$data['no_wa'].'" target="_blank" style="font-size: 15px;">+62'.$data['no_wa'].'</a>';
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript"
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/efbc88a111.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios@1.1.2/dist/axios.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script src="js/sweet-alert.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.css">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/sweetalert-dark.css">
    <title>Dashboard |
        <?php echo $config['title'];?>
    </title>
</head>

<body>
    <nav id="_sidebar" class="sidebar shadow close">
        <header>
            <div class="image-text">
                <span class="image">
                    <?php fotoProfil(1); ?>

                </span>

                <div class="text logo-text">
                    <span class="name" id="name"></span>
                    <span class="profession" id="role"></span>
                </div>
            </div>

            <i class='bx bx-chevron-right toggle'></i>
        </header>

        <div class="menu-bar">
            <div class="menu">

                <li class="search-box" style="display: none;">
                    <i class='bx bx-search icon'></i>
                    <input type="text" placeholder="Search..." id="search">
                </li>


                <li class="">
                    <a href="javascript:void(0)" onclick="menu('dashboard', 'Dashboard');history.replaceState(null,'','?menu=dashboard');">
                        <i class='bx bx-home-alt icon'></i>
                        <span class="text nav-text">Dashboard</span>
                    </a>
                </li>

                <li class="">
                    <a href="javascript:void(0)" onclick="menu('profil', 'Profil');history.replaceState(null,'','?menu=profil');">
                        <i class='bx bx-user icon'></i>
                        <span class="text nav-text">Profil</span>
                    </a>
                </li>

                <li class="">
                    <a href="javascript:void(0)" onclick="menu('sertifikat', 'Sertifikat');history.replaceState(null,'','?menu=sertifikat');">
                        <i class='bx bx-file-blank icon'></i>
                        <span class="text nav-text">Sertifikat</span>
                    </a>
                </li>


            </div>

            <div class="bottom-content">
                <li class="separator">
                </li>

                <li class="">
                    <a href="#" onclick="swal(16,'');">
                        <i class='bx bx-log-out icon'></i>
                        <span class="text nav-text">Logout</span>
                    </a>
                </li>

                <li class="mode">
                    <div class="sun-moon">
                        <i class='bx bx-moon icon moon'></i>
                        <i class='bx bx-sun icon sun'></i>
                    </div>
                    <span class="mode-text text">Dark mode</span>

                    <div class="toggle-switch">
                        <span class="switch"></span>
                    </div>
                </li>

            </div>
        </div>

    </nav>

    <section class="" id="home-container">
        <div class="" id="text-container">
            <div id="_dashboard-container">
                <div class="" id="title-container">
                    <span class="font-weight-bold" id="title-text"></span>
                </div>


                <?php
                include('php/dashboard.php');
                include('php/profil.php');
                include('php/sertifikat.php');
                ?>


            </div>
        </div>
    </section>
    <?php varSkill();?>
    <script src="js/index.js"></script>
    <script src="js/device-check.js"></script>
    <?php setData();
    if (isset($_GET['menu'])) {
        $menu = $_GET['menu'];
        if ($menu == 'dashboard' or $menu == 'profil' or $menu == 'sertifikat'){
            $menu = $menu;
        } else{
            echo "<script>
            history.replaceState(null,'','?menu=dashboard');
            alert('sql injection not working in here!');
            </script>";
            $menu = "dashboard";
        }
        echo "<script>
            menu('".$menu."', '".ucfirst($menu)."');
        </script>";
    } else if (!isset($_GET['menu'])) {
        echo "<script>
            history.replaceState(null,'','?menu=dashboard');
            </script>";
        $menu = "dashboard";
        echo "<script>
            menu('".$menu."', '".ucfirst($menu)."');
        </script>";
    }

    ?>
</body>

</html>
