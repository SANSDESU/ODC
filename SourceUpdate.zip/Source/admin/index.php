<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript"
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/efbc88a111.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
    <script src="js/sweet-alert.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.css">
    <link rel="stylesheet" href="css/sweetalert-dark.css">
    <link rel="stylesheet" href="css/index.css">
    <title>Dashboard Admin | BKK-SOJI</title>
</head>

<style>
    /* Tema */
    *{
    --primary:#439238;
    --secondary:#6abb5f;
    }
</style>

<body>
    <nav id="_sidebar" class="sidebar close">
        <header>
            <div class="image-text">
                <span class="image">
                    <img src="http://localhost/ODC/foto/profil.png" alt="profile">
                </span>

                <div class="text logo-text">
                    <span class="name" id="name-text">Surya Hadini</span>
                    <span class="profession" id="role">Administrator</span>
                </div>
            </div>

            <i class='bx bx-chevron-right toggle'></i>
        </header>

        <div class="menu-bar">
            <div class="menu">

                <li class="search-box" style="display: none;">
                    <i class='bx bx-search icon'></i>
                    <input type="text" placeholder="Search..." id="search">
                </li>


                <li class="">
                    <a href="#" onclick="menu('_dash', 'Dashboard Admin');">
                        <i class='bx bx-server icon'></i>
                        <span class="text nav-text">Dashboard</span>
                    </a>
                </li>

                <li class="">
                    <a href="#" onclick="menu('_user', 'User');">
                        <i class='bx bx-user icon'></i>
                        <span class="text nav-text">User</span>
                    </a>
                </li>

                <li class="">
                    <a href="#" onclick="menu('_mail', 'Mail');">
                        <i class='bx bx-envelope icon'></i>
                        <span class="text nav-text">Mail</span>
                    </a>
                </li>

                <li class="separator">
                </li>

                <li class="">
                    <a href="#" onclick="menu('_news', 'Berita');">
                        <i class='bx bx-news icon'></i>
                        <span class="text nav-text">Berita</span>
                    </a>
                </li>

                <li class="separator">
                </li>

                <li class="">
                    <a href="#" onclick="menu('_db', 'Database');">
                        <i class='bx bx-data icon'></i>
                        <span class="text nav-text">Database</span>
                    </a>
                </li>

                <li class="">
                    <a href="#" onclick="menu('_admin_setting', 'Pengaturan');">
                        <i class='bx bx-cog icon'></i>
                        <span class="text nav-text">Pengaturan</span>
                    </a>
                </li>


            </div>

            <div class="bottom-content">
                <li class="separator">
                </li>

                <li class="">
                    <a href="#" onclick="swal(16,'');">
                        <i class='bx bx-log-out icon'></i>
                        <span class="text nav-text">Logout</span>
                    </a>
                </li>

                <li class="mode">
                    <div class="sun-moon">
                        <i class='bx bx-moon icon moon'></i>
                        <i class='bx bx-sun icon sun'></i>
                    </div>
                    <span class="mode-text text">Dark mode</span>

                    <div class="toggle-switch">
                        <span class="switch"></span>
                    </div>
                </li>

            </div>
        </div>

    </nav>

    <section class="" id="home-container">
        <div class="" id="text-container">
            <div id="_dashboard-container">
                <div class="" id="title-container">
                    <span class="font-weight-bold" id="title-text"></span>
                </div>
                <div id="_dash" style="display: block;">
                    <div class="container mt-3">
                        <div class="row mb-3">

                            <div class="col-sm-5 mr-3">
                                <div class="row">
                                    <div class="col-12 rounded shadow bg mb-3 pb-3 pt-3">
                                        <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                            profile
                                        </div-->

                                        <div class="d-flex align-items-center justify-content-between" style="font-size: 30px;">
                                            <span class="font-weight-bold text-muted" style="margin-left: 5px;">Siswa</span>
                                            <span class="font-weight-bold text-muted" style="margin-right: 5px;">190<i class='bx bxs-user ml-1 cntn blue-filter'></i></span>
                                        </div>
                                    </div>

                                    <div class="col-12 rounded shadow bg mb-3 pb-2 pt-2">
                                        <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                            profile
                                        </div-->
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 30px;">
                                            <span class="font-weight-bold text-muted" style="margin-left: 5px;">Admin</span>
                                            <span class="font-weight-bold text-muted" style="margin-right: 5px;">5<i class='bx bx-shield-quarter ml-1 cntn red-filter'></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="col-sm-6">
                                <div class="row">
                                    <div class="col-12 rounded shadow bg mb-3 pb-2 pt-2">
                                        <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                            profile
                                        </div-->
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 30px;">
                                            <span class="font-weight-bold text-muted" style="margin-left: 5px;">Industri</span>
                                            <span class="font-weight-bold text-muted" style="margin-right: 5px;">33<i class='bx bxs-business ml-1 cntn orange-filter'></i></span>
                                        </div>
                                    </div>
                                    <div class="col-12 rounded shadow bg  mb-3 pb-2 pt-2">
                                        <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                            profile
                                        </div-->
                                        <div class="d-flex align-items-center justify-content-between py-2"
                                            style="font-size: 30px;">
                                            <span class="font-weight-bold text-muted" style="margin-left: 5px;">Berita</span>
                                            <span class="font-weight-bold text-muted" style="margin-right: 5px;">20<i class='bx bx-news ml-1 cntn'></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>



                        </div>

                        <div class="row mb-3">
                            <div class="col-md-2 mr-3">

                                <div class="row">
                                    <div class="col-12 rounded shadow bg mb-3 pb-3">
                                        <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                            profile
                                        </div-->
                                        <div class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                            <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Asal Sekolah</span></div>

                                        </div>

                                        <div class="hide-scroll" style="height: 200px; overflow-y: scroll;">
                                        <div class="table-responsive">
                                            <table class="table table-responsive table-borderless text"
                                                style="font-size: 15px;">

                                                <tbody>
                                                    <tr>
                                                        <td><span class="font-weight-bold text-muted" style="margin-left: 5px; font-size: 15px;"><i class='bx bxs-school mr-1'></i>SMKN 1 Soreang</span></td>
                                                    </tr>
                                                    <tr>
                                                        <td><span class="font-weight-bold text-muted" style="margin-left: 5px; font-size: 15px;"><i class='bx bxs-school mr-1'></i>SMAN 1 Soreang</span></td>
                                                    </tr>






                                                </tbody>
                                            </table>
                                        </div>
                                    </div>




                                    </div>

                                </div>

                            </div>

                            <div class="col-md-9 mr-3">
                                <div class="row">
                                    <div class="col-12 rounded shadow bg mb-3 pb-3">
                                        <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                            profile
                                        </div-->
                                        <div class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                            <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Grafik Asal Sekolah</span></div>

                                        </div>

                                        <div class="d-flex align-items-center justify-content-center">

                                            <canvas id="chart-school" class="chartjs-render-monitor w-100" style="display: block; height: 200px;"></canvas>
                                        </div>
                                        <script>
                                            var nama_sekolah = ["SMKN 1 Soreang", "SMAN 1 Soreang"];
                                            var data_sekolah = [55, 43, 35, 24, 33];
                                            var warna_data_sekolah = ["#b91d47", "#2b5797"];

                                            new Chart("chart-school", {
                                            type: "horizontalBar",
                                            data: {
                                                labels: nama_sekolah,
                                                datasets: [{
                                                backgroundColor: warna_data_sekolah,
                                                data: data_sekolah
                                                }]
                                            },
                                                options: {
                                                         legend: {display: false}
                                                        }
                                            });


                                        </script>


                                    </div>

                                </div>
                            </div>



                        </div>

                        <div class="row mb-3">
                        <div class="col-sm-7 mr-3">
                            <div class="row">
                                <div class="col-12 rounded shadow bg mb-3 pb-3">
                                    <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                        profile
                                    </div-->
                                    <div class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                        <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Admin User</span></div>

                                    </div>
                                    <div class="hide-scroll" style="height: 295px; overflow-y: scroll;">
                                    <div class="table-responsive">
                                        <table class="table table-responsive table-borderless text"
                                            style="font-size: 15px;">
                                            <thead>
                                                <tr class="bg">
                                                    <th scope="col" width="10%">Foto</th>
                                                    <th scope="col" width="30%">User</th>
                                                    <th scope="col" width="30%">Tanggal Dibuat</th>
                                                    <th scope="col" width="20%">Role</th>
                                                    <th scope="col" class="text-end" width="20%"><span>Status</span></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><img src="http://localhost/ODC/foto/profil.png" width="25px"></td>
                                                    <td><span class="font-weight-bold">Admin 1</span></td>
                                                    <td><span class="text-muted">1 Agustus, 2023</span></td>
                                                    <td><span class="font-weight-bold text-muted">Admin</span></td>
                                                    <td class="text-end">
                                                        <div class="d-flex align-items-center">
                                                        <input checked type="checkbox" class="check-green" id="check">
                                                        <span class="ml-1 ms-1">Aktif</span>
                                                      </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><img src="http://localhost/ODC/foto/profil.png" width="25px"></td>
                                                    <td><span class="font-weight-bold">Admin 2</span></td>
                                                    <td><span class="text-muted">1 Agustus, 2023</span></td>
                                                    <td><span class="font-weight-bold text-muted">Admin</span></td>
                                                    <td class="text-end">
                                                        <div class="d-flex align-items-center">
                                                        <input type="checkbox" class="check-green" id="check">
                                                        <span class="ml-1 ms-1">Nonaktif</span>
                                                      </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><img src="http://localhost/ODC/foto/profil.png" width="25px"></td>
                                                    <td><span class="font-weight-bold">Admin 3</span></td>
                                                    <td><span class="text-muted">1 Agustus, 2023</span></td>
                                                    <td><span class="font-weight-bold text-muted">Admin</span></td>
                                                    <td class="text-end">
                                                        <div class="d-flex align-items-center">
                                                        <input checked type="checkbox" class="check-green" id="check">
                                                        <span class="ml-1 ms-1">Aktif</span>
                                                      </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><img src="http://localhost/ODC/foto/profil.png" width="25px"></td>
                                                    <td><span class="font-weight-bold">Admin 4</span></td>
                                                    <td><span class="text-muted">1 Agustus, 2023</span></td>
                                                    <td><span class="font-weight-bold text-muted">Admin</span></td>
                                                    <td class="text-end">
                                                        <div class="d-flex align-items-center">
                                                        <input type="checkbox" class="check-green" id="check">
                                                        <span class="ml-1 ms-1">Aktif</span>
                                                      </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><img src="http://localhost/ODC/foto/profil.png" width="25px"></td>
                                                    <td><span class="font-weight-bold">Admin 5</span></td>
                                                    <td><span class="text-muted">1 Agustus, 2023</span></td>
                                                    <td><span class="font-weight-bold text-muted">Admin</span></td>
                                                    <td class="text-end">
                                                        <div class="d-flex align-items-center">
                                                        <input type="checkbox" class="check-green" id="check">
                                                        <span class="ml-1 ms-1">Nonaktif</span>
                                                      </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><img src="http://localhost/ODC/foto/profil.png" width="25px"></td>
                                                    <td><span class="font-weight-bold">Admin 4</span></td>
                                                    <td><span class="text-muted">1 Agustus, 2023</span></td>
                                                    <td><span class="font-weight-bold text-muted">Admin</span></td>
                                                    <td class="text-end">
                                                        <div class="d-flex align-items-center">
                                                        <input type="checkbox" class="check-green" id="check">
                                                        <span class="ml-1 ms-1">Aktif</span>
                                                      </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><img src="http://localhost/ODC/foto/profil.png" width="25px"></td>
                                                    <td><span class="font-weight-bold">Admin 5</span></td>
                                                    <td><span class="text-muted">1 Agustus, 2023</span></td>
                                                    <td><span class="font-weight-bold text-muted">Admin</span></td>
                                                    <td class="text-end">
                                                        <div class="d-flex align-items-center">
                                                        <input type="checkbox" class="check-green" id="check">
                                                        <span class="ml-1 ms-1">Nonaktif</span>
                                                      </div>
                                                    </td>
                                                </tr>


                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                </div>

                            </div>
                        </div>


                        <div class="col-sm-4">
                            <div class="row">
                                <div class="col-12 rounded shadow bg mb-3 pb-2">
                                    <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                        profile
                                    </div-->
                                    <div class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                        <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Notifikasi</span></div>

                                    </div>

                                    <div class="d-flex align-items-center justify-content-between">

                                            <span class="font-weight-bold text-muted" style="margin-left: 5px; font-size: 17px;"><i class='bx bx-envelope mr-1'></i> Mail</span>

                                            <span class="font-weight-bold tag" style="margin-right: 5px;">99</span>
                                    </div>

                                </div>

                            </div>
                            <div class="row">
                                <div class="col-12 rounded shadow bg mb-3 pb-2">
                                    <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                        profile
                                    </div-->
                                    <div class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                        <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Grafik User</span></div>

                                    </div>

                                    <div class="d-flex align-items-center justify-content-center">

                                        <canvas id="chart-acc" class="chartjs-render-monitor" style="display: block;"></canvas>
                                    </div>
                                    <script>
                                        var xValues = ["Siswa", "Admin", "Industri"];
                                        var yValues = [190, 5, 33];
                                        var barColors = [
                                        "#62B0E0",
                                        "#FA8B91",
                                        "#D99A5C"
                                        ];

                                        new Chart("chart-acc", {
                                        type: "doughnut",
                                        data: {
                                            labels: xValues,
                                            datasets: [{
                                            backgroundColor: barColors,
                                            borderColor: "#3a3b3c",
                                            data: yValues
                                            }]
                                        }});
                                    </script>

                                </div>

                            </div>
                        </div>

                    </div>


                    </div>
                </div>

                <div id="_user" style="display: none;">
                    <div class="container rounded mt-3 mb-3">
                        <div class="row ">
                        <div class="col-sm-8 mr-3">
                            <div class="row">
                                <div class="col-12 rounded shadow bg pb-2 pt-2">
                                    <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                        profile
                                    </div-->


                        <div class="row border-bottom">
                            <div class="mb-2 d-flex justify-content-between align-items-center mt-2 mb-2 h-50" style="font-size: 15px;">

                                <div class="position-relative align-items-center bg">
                                    <span class="position-absolute search"><i class="fa fa-search"></i></span>
                                    <input class="form-control w-100" style="padding-left:32px;" placeholder="Search by order#, name...">
                                </div>

                                <div class="px-2 d-flex justify-content-between align-items-center">

                                    <span class="font-weight-bold text-muted mr-1">Show data</span>
                                    <select class="form-control-2 border-0 w-auto" value="Siswa" id="showDataBy">
                                        <option class="border-bottom" value="Siswa">Siswa</option>
                                        <option class="border-bottom" value="Admin">Admin</option>
                                        <option class="border-bottom" value="Industri">Industri</option>
                                    </select>

                                </div>

                            </div>

                            <div class="mb-2 d-flex justify-content-between align-items-center mb-2" style="font-size: 15px;">
                                <span class="font-weight-bold" style="width:12%;">Foto</span>
                                <span class="font-weight-bold" style="width:30%;">User</span>
                                <span class="font-weight-bold" style="width:20%;">Tanggal Dibuat</span>
                                <span class="font-weight-bold" style="width:15%;">Role</span>
                                <span class="font-weight-bold" style="width:15%;">Status</span>
                                <span class="font-weight-bold" style="width:10%;">Aksi</span>



                            </div>

                        </div>

                        <div class="hide-scroll" style="height: 500px; overflow-y: scroll;">
                        <div class="row">
                            <div class="table-responsive">
                                <table class="table table-responsive table-borderless text" style="font-size: 15px;">
                                    <thead>
                                        <tr class="bg">
                                            <th scope="col" width="10%"></th>
                                            <th scope="col" width="30%"></th>
                                            <th scope="col" width="20%"></th>
                                            <th scope="col" width="15%"></th>
                                            <th scope="col" width="15%"></th>
                                            <th scope="col" class="text-end" width="20%"></th>
                                        </tr>
                                      </thead>

                                <tbody id="data_siswa">

                                    <tr>
                                        <td><img src="http://localhost/ODC/foto/profil.png" width="25px"></td>
                                        <td><span class="font-weight-bold">Siswa Aktif</span></td>
                                        <td><span class="text-muted">1 Agustus, 2023</span></td>
                                        <td><span class="font-weight-bold text-muted">Siswa</span></td>
                                        <td class="text-end">
                                            <div class="d-flex align-items-center">
                                            <input checked type="checkbox" class="check-green" id="check">
                                            <span class="ml-1 ms-1">Aktif</span>
                                          </div>
                                        </td>
                                        <td><button class="btn btn-primary pickImageBtn" type="button"
                                            id="view-doc"
                                            onclick="getCurrentIndex(this,'edit')">Edit</button></td>
                                    </tr>
                                    <tr>
                                        <td><img src="http://localhost/ODC/foto/profil.png" width="25px"></td>
                                        <td><span class="font-weight-bold">Siswa Nonaktif</span></td>
                                        <td><span class="text-muted">1 Agustus, 2023</span></td>
                                        <td><span class="font-weight-bold text-muted">Siswa</span></td>
                                        <td class="text-end">
                                            <div class="d-flex align-items-center">
                                            <input type="checkbox" class="check-green" id="check">
                                            <span class="ml-1 ms-1">Nonaktif</span>
                                          </div>
                                        </td>
                                        <td><button class="btn btn-primary pickImageBtn" type="button"
                                            id="view-doc"
                                            onclick="getCurrentIndex(this,'edit')">Edit</button></td>
                                    </tr>

                                </tbody>

                                <tbody id="data_admin" style="display: none;">

                                    <tr>
                                        <td><img src="http://localhost/ODC/foto/profil.png" width="25px"></td>
                                        <td><span class="font-weight-bold">Admin Aktif</span></td>
                                        <td><span class="text-muted">1 Agustus, 2023</span></td>
                                        <td><span class="font-weight-bold text-muted">Admin</span></td>
                                        <td class="text-end">
                                            <div class="d-flex align-items-center">
                                            <input checked type="checkbox" class="check-green" id="check">
                                            <span class="ml-1 ms-1">Aktif</span>
                                          </div>
                                        </td>
                                        <td><button class="btn btn-primary pickImageBtn" type="button"
                                            id="view-doc"
                                            onclick="getCurrentIndex(this,'edit')">Edit</button></td>
                                    </tr>
                                    <tr>
                                        <td><img src="http://localhost/ODC/foto/profil.png" width="25px"></td>
                                        <td><span class="font-weight-bold">Admin Nonaktif</span></td>
                                        <td><span class="text-muted">1 Agustus, 2023</span></td>
                                        <td><span class="font-weight-bold text-muted">Admin</span></td>
                                        <td class="text-end">
                                            <div class="d-flex align-items-center">
                                            <input type="checkbox" class="check-green" id="check">
                                            <span class="ml-1 ms-1">Nonaktif</span>
                                          </div>
                                        </td>
                                        <td><button class="btn btn-primary pickImageBtn" type="button"
                                            id="view-doc"
                                            onclick="getCurrentIndex(this,'edit')">Edit</button></td>
                                    </tr>

                                </tbody>

                                <tbody id="data_industri" style="display: none;">

                                    <tr>
                                        <td><img src="http://localhost/ODC/foto/profil.png" width="25px"></td>
                                        <td><span class="font-weight-bold">Industri Aktif</span></td>
                                        <td><span class="text-muted">1 Agustus, 2023</span></td>
                                        <td><span class="font-weight-bold text-muted">Industri</span></td>
                                        <td class="text-end">
                                            <div class="d-flex align-items-center">
                                            <input checked type="checkbox" class="check-green" id="check">
                                            <span class="ml-1 ms-1">Aktif</span>
                                          </div>
                                        </td>
                                        <td><button class="btn btn-primary pickImageBtn" type="button"
                                            id="view-doc"
                                            onclick="getCurrentIndex(this,'edit')">Edit</button></td>
                                    </tr>
                                    <tr>
                                        <td><img src="http://localhost/ODC/foto/profil.png" width="25px"></td>
                                        <td><span class="font-weight-bold">Industri Nonaktif</span></td>
                                        <td><span class="text-muted">1 Agustus, 2023</span></td>
                                        <td><span class="font-weight-bold text-muted">Industri</span></td>
                                        <td class="text-end">
                                            <div class="d-flex align-items-center">
                                            <input type="checkbox" class="check-green" id="check">
                                            <span class="ml-1 ms-1">Nonaktif</span>
                                          </div>
                                        </td>
                                        <td><button class="btn btn-primary pickImageBtn" type="button"
                                            id="view-doc"
                                            onclick="getCurrentIndex(this,'edit')">Edit</button></td>
                                    </tr>

                                </tbody>

                                </table>

                              </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="d-flex align-items-center justify-content-between px-3 mt-3" style="font-size: 15px;">
                                <div class="d-flex justify-content-start mb-2"><span>Page</span><input class="ml-1 input-10 text-center form-control" style="width: 50px;" type="number" value="1"> <span><span class="px-1">of</span>1</span></div>
                                <div class="d-flex justify-content-end mb-2"> <span class="pe-1">Show</span> <input class="ml-1 mr-1 input-10 text-center form-control" style="width: 50px;" type="number" value="5"> <span class="ps-2"><span class="pe-2">/</span>Page</span> </div>
                            </div>
                        </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-3">
                            <div class="row">
                                <div class="col-12 rounded shadow bg mb-3 pb-2">
                                    <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                        profile
                                    </div-->
                                    <div class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                        <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Menu User</span></div>

                                    </div>

                                    <div class="row p-3">
                                        <button class="btn btn-primary profile-button" type="button" onclick="getCurrentIndex(this, 'create')">Buat User</button>
                                        <button class="btn btn-primary profile-button mt-2 mb-2 blue-filter" type="button" onclick="getCurrentIndex(this, 'import')">Import User</button>
                                        <button class="btn btn-primary profile-button orange-filter" type="button" onclick="getCurrentIndex(this, 'export')">Export Data</button>

                                    </div>

                                </div>

                            </div>
                            <div class="row">
                                <div class="col-12 rounded shadow bg mb-3 pb-2">
                                    <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                        profile
                                    </div-->
                                    <div class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                        <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Menu Admin</span></div>

                                    </div>

                                    <div class="row p-3">
                                        <button class="btn btn-primary profile-button" type="button" onclick="getCurrentIndex(this, 'sekolah')">Tambah Sekolah</button>
                                        <button class="btn btn-primary profile-button mt-2 mb-2 blue-filter" type="button" onclick="getCurrentIndex(this, 'kategori')">Tambah Kategori</button>
                                        <button class="btn btn-primary profile-button orange-filter" type="button" onclick="getCurrentIndex(this, 'editData')">Edit Data</button>

                                    </div>

                                </div>

                            </div>
                            <div class="row">
                                <div class="col-12 rounded shadow bg mb-3 pb-2">
                                    <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                        profile
                                    </div-->
                                    <div class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                        <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Grafik Data</span></div>

                                    </div>

                                    <div class="d-flex align-items-end h-75">

                                        <canvas id="chart-acc-2" class="chartjs-render-monitor d-flex align-items-end" style="display: block;"></canvas>
                                    </div>
                                    <script>
                                        var xValues = ["Siswa", "Admin", "Industri", "Sekolah", "Kategori"];
                                        var yValues = [190, 150, 100, 75, 50];
                                        var barColors = [
                                        "#62B0E0",
                                        "#FA8B91",
                                        "#D99A5C",
                                        "#a1fa8b",
                                        "#a38bfa"
                                        ];

                                        new Chart("chart-acc-2", {
                                        type: "bar",
                                        data: {
                                            labels: xValues,
                                            datasets: [{
                                            backgroundColor: barColors,
                                            borderColor: "#3a3b3c",
                                            data: yValues
                                            }]
                                        },options: {
                                            /*scales: {
                                                    yAxes: [{
                                                    ticks: {
                                                        reverse: true,
                                                    }
                                                    }]
                                                },*/

                                            responsive: true,
                                            maintainAspectRatio: true,
                                            legend:{
                                                    display:false
                                            }
                                        }});
                                    </script>

                                </div>

                            </div>
                        </div>

                    </div>
                    </div>
                </div>

                <div id="_mail" style="display: none;">
                    <div class="container mt-3 mb-3">
                        <div class="row">
                            <div class="col-sm-3 mr-3">
                                <div class="row">
                                    <div class="col-12 rounded shadow bg mb-3 pb-2">
                                        <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                            profile
                                        </div-->
                                        <div class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                            <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Menu</span></div>

                                        </div>



                                    </div>

                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="row">
                                    <div class="col-12 rounded shadow bg mb-3 pb-2">
                                        <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                            profile
                                        </div-->
                                        <div class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                            <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Menu</span></div>

                                        </div>



                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="_news" style="display: none;">
                    <div class="container rounded mt-3 mb-3">
                        <div class="row mb-3">
                            <div class="col-sm-6 mr-3">

                                <div class="row">
                                    <div class="col-12 rounded bg mb-3 pb-3">
                                        <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                            profile
                                        </div-->
                                        <div class="row d-flex justify-content-center align-content-center mb-2">

                                            <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Berita</span></div>

                                        </div>
                                        <div class="hide-scroll" style="height: 295px; overflow-y: scroll;">
                                        <div class="table-responsive">
                                            <table class="table table-responsive table-borderless text"
                                                style="font-size: 15px;">
                                                <thead class="border-bottom mr-1 ml-1">
                                                    <tr class="bg">
                                                        <th scope="col" width="10%">No</th>
                                                        <th scope="col" width="30%">Judul</th>
                                                        <th scope="col" width="30%">Tanggal Dibuat</th>
                                                        <th scope="col" class="text-end" width="30%"><span>Aksi</span></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>1</td>
                                                        <td><span class="font-weight-bold">Tes Judul</span></td>
                                                        <td><span class="text-muted">1 Agustus, 2023</span></td>
                                                        <td class="text-end">
                                                            <button class="btn btn-primary pickImageBtn blue-filter" type="button"
                                                                id="view-doc">Buka</button>
                                                            <button class="btn btn-primary pickImageBtn" type="button"
                                                                id="edit-doc">Edit</button>
                                                            <button class="btn btn-primary pickImageBtn red-filter" type="button"
                                                                id="delete-doc">Hapus</button>
                                                        </td>
                                                    </tr>



                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    </div>

                                </div>
                            </div>


                            <div class="col-sm-5">
                                <div class="row">
                                    <div class="col-12 rounded bg mb-3 pb-2">
                                        <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                            profile
                                        </div-->
                                        <div class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                            <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Posting Berita</span></div>

                                        </div>

                                        <div class="w-100 d-flex justify-content-center ">
                                            <textarea class="form-control hide-scroll" style=" resize:none" id="preview" placeholder="Tulis Berita" rows="7" cols="50"></textarea>
                                        </div>

                                        <div class="row p-3">
                                            <button class="btn btn-primary profile-button" type="button">Posting</button>
                                        </div>

                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div id="_db" style="display: none;">
                    <div class="container mt-3 mb-3">
                        <div class="row">
                            <div class="col-sm-3 mr-3">
                                <div class="row">
                                    <div class="col-12 rounded shadow bg mb-3 pb-2">
                                        <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                            profile
                                        </div-->
                                        <div class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                            <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Menu</span></div>

                                        </div>



                                    </div>

                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="row">
                                    <div class="col-12 rounded shadow bg mb-3 pb-2">
                                        <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                            profile
                                        </div-->
                                        <div class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                            <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Menu</span></div>

                                        </div>



                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="_admin_setting" style="display: none;">
                    <div class="container rounded mt-3 mb-3 ">
                        <div class="row d-flex justify-content-center align-content-center">
                            <div class="col-sm-4 rounded shadow mr-3 mb-3 bg">
                                <div class="d-flex flex-column align-items-center p-3">
                                    <input id="imageInput" type="file" style="visibility: hidden;"
                                        onchange="document.getElementById('pfp').src = window.URL.createObjectURL(this.files[0])" />
                                    <img id="pfp" class="rounded-circle" height="50%" width="50%"
                                        src="http://localhost/ODC/foto/profil.png">
                                    <!--i class='bx bxs-pencil topright' onclick="pickImage();" style="cursor: pointer;"></i-->
                                    <button class="btn btn-primary pickImageBtn" type="button"
                                        onclick="pickImage();" id="save-profile">Ubah Foto Profil</button>
                                    <!--span class="font-weight-bold" id="name-text">Surya</span-->
                                    <div class="col-md-12"><label class="labels">Nama</label><input type="text"
                                        class="form-control" placeholder="Masukkan Nama"
                                        value="" id="address"></div>
                                    <div class="row">
                                        <div class="col-md-6"><label class="labels">Password Lama</label><input type="password"
                                                class="form-control" placeholder="Masukkan Password Lama"
                                                value="" id="address"></div>
                                        <div class="col-md-6"><label class="labels">Password Baru</label><input type="password"
                                                class="form-control" placeholder="Masukkan Password Baru"
                                                value="" id="address"></div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12"><label class="labels">Nomor Handphone</label><input
                                                type="number" class="form-control" value="" placeholder="Masukkan No HP"
                                                id="mobile-number"></div>
                                        <div class="col-md-12"><label class="labels">Email</label><input type="text"
                                                class="form-control" value="" placeholder="Masukkan Email" id="email">
                                        </div>

                                    </div>

                                    <div class="mt-3 text-center"><button class="btn btn-primary profile-button"
                                            type="button" onclick="swal(7,'Perubahan Telah Disimpan');"
                                            id="save-profile">Simpan Perubahan</button></div>

                                </div>
                            </div>
                            <div class="col-sm-3 mr-3">
                                <div class="row">
                                    <div class="col-12 rounded shadow bg mb-3 pb-2">
                                        <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                            profile
                                        </div-->
                                        <div class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                            <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Pengaturan Export</span></div>

                                        </div>

                                        <div class="p-3" style="font-size: 15px;">
                                            <div class="col-md-12 d-flex justify-content-start">
                                                <input checked type="checkbox" class="check-green" id="check">
                                                <span class="ml-1 ms-1">Username</span>
                                            </div>
                                            <div class="col-md-12 d-flex justify-content-start">
                                                <input type="checkbox" class="check-green" id="check">
                                                <span class="ml-1 ms-1">Password</span>
                                            </div>
                                            <div class="col-md-12 d-flex justify-content-start">
                                                <input checked type="checkbox" class="check-green" id="check">
                                                <span class="ml-1 ms-1">Email</span>
                                            </div>
                                            <div class="col-md-12 d-flex justify-content-start">
                                                <input checked type="checkbox" class="check-green" id="check">
                                                <span class="ml-1 ms-1">Detail (ID,Role,dll)</span>
                                            </div>
                                            <div class="col-md-12 d-flex justify-content-start">
                                                <input type="checkbox" class="check-green" id="check">
                                                <span class="ml-1 ms-1">Semua Data Siswa</span>
                                            </div>
                                            <div class="col-md-12 d-flex justify-content-start">
                                                <input type="checkbox" class="check-green" id="check">
                                                <span class="ml-1 ms-1">Export All</span>
                                            </div>
                                        </div>
                                        <div class="mt-3 text-center"><button class="btn btn-primary profile-button"
                                            type="button" onclick="swal(7,'Perubahan Telah Disimpan');"
                                            id="save-profile">Simpan Perubahan</button></div>


                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-12 rounded shadow bg mb-3 pb-2">
                                        <!--div class="d-flex align-items-center justify-content-between border-bottom">
                                            profile
                                        </div-->
                                        <div class="row d-flex justify-content-center align-content-center border-bottom mb-2 mr-1 ml-1">

                                            <div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">Tampilan</span></div>

                                        </div>
                                        <div class="row">
                                            <div class="col-md-6"><label class="labels">Warna Utama</label><input type="color"
                                                    class="form-control" value="#439238"
                                                    value="" id=""></div>
                                            <div class="col-md-6"><label class="labels">Warna Kedua</label><input type="color"
                                                    class="form-control" value="#6abb5f"
                                                    value="" id=""></div>
                                        </div>
                                        <div class=" text-center"><button class="btn btn-primary pickImageBtn"
                                            type="button"
                                            id="save-profile">Reset</button></div>

                                        <div class="mt-3 text-center"><button class="btn btn-primary profile-button"
                                            type="button" onclick="swal(7,'Perubahan Telah Disimpan');"
                                            id="save-profile">Simpan Perubahan</button></div>

                                    </div>

                                </div>
                            </div>

                        </div>



                    </div>
                </div>


            </div>
        </div>
    </section>
    <script src="js/index.js"></script>
    <script src="js/modal-menu.js"></script>
    <script src="js/device-check.js"></script>
</body>

</html>