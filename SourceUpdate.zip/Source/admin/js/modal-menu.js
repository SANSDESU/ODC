$("#showDataBy").on("change", function() {
    var selectedValue = $(this).val();

    // Hide all content divs
    $("#data_siswa, #data_admin, #data_industri").hide();

    // Show the specific content based on the selected value
    if (selectedValue === "Siswa") {
        $("#data_siswa").show();
    } else if (selectedValue === "Admin") {
        $("#data_admin").show();
    } else if (selectedValue === "Industri") {
        $("#data_industri").show();
    }
});

function getDataFromRow(rowElement) {
    var tdValues = [];

    $(rowElement).find('td').each(function() {
        var tdValue = $(this).text().trim();
        tdValues.push(tdValue);
    });

    return tdValues;
}

function getCurrentIndex(buttonElement, option) {
    var rowElement = $(buttonElement).closest('tr')[0];
    var dataIndex = $(rowElement).index();

    var rowData = getDataFromRow(rowElement);

    if (option == "create"){
        userOptions('Buat User', 'Email', 'Masukkan Password', 'Buat', '', 'Siswa', 'Aktif', '');
    } else if (option == "edit"){
        userOptions('Edit User', 'Username', 'Biarkan kosong jika tidak dirubah', 'Simpan', rowData[1], rowData[3], rowData[4], '');

    } else if (option == "import"){
        userOptions('Import Data User', 'Import', '', 'Import', '', '', '', 'imp');

    } else if (option == "export"){
        userOptions('Export Data User', 'Export', '', 'Export', '', '', '', 'exp');

    }


    else if (option == "sekolah"){
        adminOptions('Tambah Sekolah', 'Nama Sekolah', '', 'Tambah', '', '', '', 'sch');

    } else if (option == "kategori"){
        adminOptions('Tambah Kategori', '', '', 'Tambah', '', '', '', 'ctg');

    } else if (option == "editData"){
        adminOptions('Edit Data', '', '', 'Simpan', '', '', '', '');

    } else if (option == "alert"){
        alert(rowData);
    } else {
        return {
            index: dataIndex,
            data: rowData
        };
    }

}

function adminOptions(titles, account, passwd, saves, userdat, roledat, statusdat, optional){
    title_menu = titles;
    acc = account;
    sv = saves;
    pass = passwd;

    title_content =
    '<div class="container rounded bg p-3" style="overflow: hidden;">'+

    '<div class="row d-flex justify-content-center align-content-center border-bottom mb-2 pb-1">'+
    '<div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">'+title_menu+'</span>'+
    '</div></div>'+
    '<div class="row d-flex justify-content-center align-content-center">';

    if (optional == 'sch'){
        html_content =
        '<div class="col-md-12"><label class="labels">'+acc+'</label><input type="text"'+
            'class="form-control" placeholder="Masukkan '+acc+'"'+
            'value="" id="edit_user">'+
        '</div>';

        footer_content =
        '<div class="w-50 mt-3 d-flex justify-content-between">'+
            '<button class="btn btn-primary profile-button" type="button" onclick="swal(7,'+"'Perubahan Telah Disimpan'"+');" id="save-profile">'+sv+'</button>'+
            '<button class="btn btn-primary profile-button red-filter" type="button" onclick="Swal.close()">Batal</button>'+
        '</div>'+
        '</div></div>';

    } else if (optional == 'ctg'){
        html_content =
        '<div class="col-md-12">'+
        '<div class="w-100 d-flex justify-content-center ">'+
            '<textarea class="form-control hide-scroll" style="background:transparent; resize:none" id="preview" placeholder="Gunakan tanda (,) jika ingin memasukkan lebih dari 1 kategori\ncontoh: memasak,melayani,dll"'+
            'rows="7" cols="50">'+
            '</textarea>'+
        '</div></div>';

        footer_content =
        '<div class="w-50 mt-3 d-flex justify-content-between">'+
            '<button class="btn btn-primary profile-button" type="button" onclick="swal(7,'+"'Perubahan Telah Disimpan'"+');" id="save-profile">'+sv+'</button>'+
            '<button class="btn btn-primary profile-button red-filter" type="button" onclick="Swal.close()">Batal</button>'+
        '</div>'+
        '</div></div>';

    } else {
        html_content =
        '<div class="row">'+
            '<div class="col">'+
                '<label class="labels">Kategori Lama</label>'+
                '<select class="form-control" placeholder="Pilih Kategori" id="edit_role">'+
                '<option value="Kategori1">Kategori1</option>'+
                '<option value="Kategori2">Kategori2</option>'+
                '</select>'+
            '</div>'+
            '<div class="col">'+
                '<label class="labels">Kategori Baru</label>'+
                '<input type="text" class="form-control" value="" placeholder="Masukkan Kategori" id="edit_user">'+
            '</div>'+
            '<div class="col">'+
            '<label class="labels">Simpan Kategori</label>'+
            '<button class="btn btn-primary profile-button w-100" type="button" onclick="swal(7,'+"'Perubahan Telah Disimpan'"+');" id="save-profile">'+sv+'</button>'+
            '</div>'+
        '</div>'+

        '<div class="row mt-2 pb-3 border-bottom ">'+
            '<div class="col">'+
                '<label class="labels">Nama Sekolah Lama</label>'+
                '<select class="form-control" placeholder="Pilih Kategori" id="edit_role">'+
                '<option value="smkn1soreang">smkn1soreang</option>'+
                '<option value="sman1soreang">sman1soreang</option>'+
                '</select>'+
            '</div>'+
            '<div class="col">'+
                '<label class="labels">Nama Sekolah Baru</label>'+
                '<input type="text" class="form-control" value="" placeholder="Masukkan Nama Sekolah" id="edit_user">'+
            '</div>'+
            '<div class="col">'+
                '<label class="labels">Simpan Sekolah</label>'+
                '<button class="btn btn-primary profile-button w-100" type="button" onclick="swal(7,'+"'Perubahan Telah Disimpan'"+');" id="save-profile">'+sv+'</button>'+
            '</div>'+
        '</div>'+

        '<div class="row mt-2">'+
            '<div class="col">'+
                '<label class="labels">Kategori</label>'+
                '<select class="form-control" placeholder="Pilih Kategori" id="edit_role">'+
                '<option value="Kategori1">Kategori1</option>'+
                '<option value="Kategori2">Kategori2</option>'+
                '</select>'+
            '</div>'+
            '<div class="col">'+
                '<label class="labels">Hapus Kategori</label>'+
                '<button class="btn btn-primary profile-button w-100 red-filter" type="button" onclick="swal(7,'+"'Perubahan Telah Disimpan'"+');" id="save-profile">Hapus</button>'+
            '</div>'+
        '</div>'+

        '<div class="row mt-2">'+
            '<div class="col">'+
                '<label class="labels">Sekolah</label>'+
                '<select class="form-control" placeholder="Pilih Kategori" id="edit_role">'+
                '<option value="smkn1soreang">smkn1soreang</option>'+
                '<option value="sman1soreang">sman1soreang</option>'+
                '</select>'+
            '</div>'+
            '<div class="col">'+
                '<label class="labels">Hapus Sekolah</label>'+
                '<button class="btn btn-primary profile-button w-100 red-filter" type="button" onclick="swal(7,'+"'Perubahan Telah Disimpan'"+');" id="save-profile">Hapus</button>'+
            '</div>'+
        '</div>';

        footer_content =
        '<div class="w-100 mt-5 d-flex justify-content-end">'+
            '<button class="btn btn-primary profile-button red-filter" type="button" onclick="Swal.close()">Tutup</button>'+
        '</div>'+
        '</div></div>';
    }



    Swal.fire({
        background: 'transparent',
        customClass: 'swal-rmv-padding',
        html: title_content+html_content+footer_content ,
        showDenyButton: false,
        showCancelButton: false,
        showConfirmButton: false,
      })
}

function userOptions(titles, account, passwd, saves, userdat, roledat, statusdat, optional){
    title_menu = titles;
    acc = account;
    sv = saves;
    pass = passwd;

    title_content =
    '<div class="container rounded bg p-3" style="overflow: hidden;">'+

    '<div class="row d-flex justify-content-center align-content-center border-bottom mb-2 pb-1">'+
    '<div class="col-6" style="width: auto;"><span class="font-weight-bold cntn" style="font-size: 20px;">'+title_menu+'</span>'+
    '</div></div>'+
    '<div class="row mt-3 d-flex justify-content-center align-content-center">';

    if (optional == 'imp'){
        html_content =
        '<div class="col-md-12">'+
        '<div class="w-100 d-flex justify-content-center ">'+
            '<textarea disabled class="form-control hide-scroll" style="background:transparent; resize:none" id="preview" placeholder="Preview Data"'+
            'rows="7" cols="50">'+
            '</textarea>'+
        '</div></div>';

        footer_content =
        '<div class="col-md-12 ml-2 mt-2">'+
            '<button class="w-75 btn btn-primary profile-button blue-filter" type="button" onclick="Swal.close()">Import Dari Excel</button>'+
        '</div>'+
        '<div class="col-md-12 ml-2 mt-1">'+
            '<button class="w-75 btn btn-primary profile-button orange-filter" type="button" onclick="Swal.close()">Download Template Excel</button>'+
        '</div>'+
        '<div class="w-50 mt-3 d-flex justify-content-between">'+
            '<button class="btn btn-primary profile-button" type="button" onclick="swal(7,'+"'Perubahan Telah Disimpan'"+');" id="save-profile">'+sv+'</button>'+
            '<button class="btn btn-primary profile-button red-filter" type="button" onclick="Swal.close()">Batal</button>'+
        '</div>'+
        '</div></div>';

    } else if (optional == 'exp'){
        html_content =
        '<div class="w-50">'+
        '<div class="col-md-12 d-flex justify-content-start">'+
            '<input checked type="checkbox" class="check-green" id="check">'+
            '<span class="ml-1 ms-1">Username</span>'+
        '</div>'+
        '<div class="col-md-12 d-flex justify-content-start">'+
            '<input type="checkbox" class="check-green" id="check">'+
            '<span class="ml-1 ms-1">Password</span>'+
        '</div>'+
        '<div class="col-md-12 d-flex justify-content-start">'+
            '<input checked type="checkbox" class="check-green" id="check">'+
            '<span class="ml-1 ms-1">Email</span>'+
        '</div>'+
        '<div class="col-md-12 d-flex justify-content-start">'+
            '<input checked type="checkbox" class="check-green" id="check">'+
            '<span class="ml-1 ms-1">Detail (ID,Role,dll)</span>'+
        '</div>'+
        '<div class="col-md-12 d-flex justify-content-start">'+
            '<input type="checkbox" class="check-green" id="check">'+
            '<span class="ml-1 ms-1">Semua Data Siswa</span>'+
        '</div>'+
        '<div class="col-md-12 d-flex justify-content-start">'+
            '<input type="checkbox" class="check-green" id="check">'+
            '<span class="ml-1 ms-1">Export All</span>'+
        '</div>'+
        '</div>'+

        '<div class="col-md-12">'+
        '</div>';

        footer_content =
        '<div class="w-50 mt-3 d-flex justify-content-between">'+
            '<button class="btn btn-primary profile-button" type="button" onclick="swal(7,'+"'Perubahan Telah Disimpan'"+');" id="save-profile">'+sv+'</button>'+
            '<button class="btn btn-primary profile-button red-filter" type="button" onclick="Swal.close()">Batal</button>'+
        '</div>'+
        '</div></div>';

    } else {
        html_content =
        '<div class="col-md-12"><label class="labels">'+acc+'</label><input type="text"'+
            'class="form-control" placeholder="Masukkan '+acc+'"'+
            'value="" id="edit_user">'+
        '</div>'+

        '<div class="col-md-12"><label class="labels">Password</label>'+
            '<input type="password" class="form-control" placeholder="'+pass+'"'+
            'value="" id="edit_pass">'+
        '</div>'+

        '<div class="row mt-2 d-flex justify-content-center">'+
            '<div class="col-md-3"><label class="labels">Role</label>'+
                '<select class="form-control" placeholder="Pilih Role" id="edit_role">'+
                '<option value="Siswa">Siswa</option>'+
                '<option value="Admin">Admin</option>'+
                '<option value="Industri">Industri</option>'+
                '</select>'+
            '</div>'+

            '<div class="col-md-3"><label class="labels">Status</label>'+
                '<select class="form-control" placeholder="Pilih Status" id="edit_status">'+
                '<option value="Aktif">Aktif</option>'+
                '<option value="Nonaktif">Nonaktif</option>'+
                '</select>'+
            '</div>'+
        '</div>';

        footer_content =
        '<div class="w-50 mt-5 d-flex justify-content-between">'+
            '<button class="btn btn-primary profile-button" type="button" onclick="swal(7,'+"'Perubahan Telah Disimpan'"+');" id="save-profile">'+sv+'</button>'+
            '<button class="btn btn-primary profile-button red-filter" type="button" onclick="Swal.close()">Batal</button>'+
        '</div>'+
        '</div></div>';
    }



    Swal.fire({
        background: 'transparent',
        customClass: 'swal-rmv-padding',
        html: title_content+html_content+footer_content ,
        showDenyButton: false,
        showCancelButton: false,
        showConfirmButton: false,
      })
      $("#edit_user").val(userdat);
      $("#edit_role").val(roledat);
      $("#edit_status").val(statusdat);
}