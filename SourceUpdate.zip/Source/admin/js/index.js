
const body = document.querySelector('body'),
    sidebar = body.querySelector('nav'),
    toggle = body.querySelector(".toggle"),
    searchBtn = body.querySelector(".search-box"),
    modeSwitch = body.querySelector(".toggle-switch"),
    modeText = body.querySelector(".mode-text");


toggle.addEventListener("click", () => {
    sidebar.classList.toggle("close");
})

searchBtn.addEventListener("click", () => {
    sidebar.classList.remove("close");
})

modeSwitch.addEventListener("click", () => {
    body.classList.toggle("dark");

    if (body.classList.contains("dark")) {
        modeText.innerText = "Light mode";
    } else {
        modeText.innerText = "Dark mode";

    }
});

// detect dark mode
if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    modeSwitch.click();
}

function menu(id, menu) {
    element = document.getElementById('_dashboard-container');
    title_text = document.getElementById('title-text');
    view = document.getElementById(id);

    dash = document.getElementById("_dash");
    user = document.getElementById("_user");
    mail = document.getElementById("_mail");
    news = document.getElementById("_news");
    db = document.getElementById("_db");
    admsett = document.getElementById("_admin_setting");

    var delayInMilliseconds = 100; //1 second

    if (view.style.display != 'block') {
        element.classList.remove("show");
        element.classList.add("hide");

        setTimeout(function() {
            dash.style.display = 'none';
            user.style.display = 'none';
            mail.style.display = 'none';
            news.style.display = 'none';
            db.style.display = 'none';
            admsett.style.display = 'none';


            view.style.display = 'block';
            title_text.innerHTML = menu;

            element.classList.remove("hide");
            element.classList.add("show");
        }, delayInMilliseconds);
      }
}

function pickImage(){
    document.getElementById('imageInput').click()
}


