


<?php
include "../php/url.php";

session_start();
$gagal = false;
include "../php/db-config.php";

if(!empty($_POST)) {
    $pdo = include "../php/koneksi.php";
    $roless = $_POST['roles'];
    $rls = explode(",", $config['roles']);

    if ($roless == $rls[0]){
        $db = 'super_admins';
    }

    else if ($roless == $rls[1]){
        $db = 'admins';
    }

    else if ($roless == $rls[2]){
        $db = 'teacher';
    }

    else if ($roless == $rls[3]){
        $db = 'industry';
    }
    else if ($roless == $rls[4]) {
        $db = 'student';
    }

    $query = $pdo->prepare("select * from ".$db." where username=:username");
    $query->bindParam(':username', $_POST['username'], PDO::PARAM_STR);
    $query->execute();
    $user = $query->fetch();

    if (!$user) {
        $gagal = true;
    } else if($user['aktif'] != 1 || $user['password'] != sha1($_POST['password'].$user['salt'])){
        $gagal = true;
    } else {

        $datatk = md5(uniqid(rand(), true));
        $_SESSION['browser'] = md5($_SERVER['HTTP_USER_AGENT']);
        $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
        $_SESSION['user'] = array(
            'id' => $user['id'],
            'nama' => $user['nama'],
            'role' => $user['role'],
            'token' => $datatk
        );
        //echo '<script>alert("'.$_SESSION['user']['token'].'");</script>';

        if ($roless == $rls[0]){
            header("Location: ".host_name()."/admin/index.php");
        }

        else if ($roless == $rls[1]){
            header("Location: ".host_name()."/admin/index.php");
        }

        else if ($roless == $rls[2]){
            header("Location: ".host_name()."/admin/index.php");
        }

        else if ($roless == $rls[3]){
            header("Location: ".host_name()."/user/index.php");
        }
        else if ($roless == $rls[4]) {
            header("Location: ".host_name()."/user/index.php");
        }
        $pdo->close();
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript"
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://kit.fontawesome.com/efbc88a111.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="css/login.css">
    <script src="js/login.js"></script>
    <title>Login | <?php echo $config['title'];?></title>


</head>


<?php
echo '
<style>
    body{
	background-image: url("'.hostname('/foto/bg.jpg').'");
	/*background-color: #636363;*/
}
</style>
';
?>

<body>
    <div class="container">

        <div class="row d-flex justify-content-center align-items-center center ml-2 mr-2">
            <div id="_main" class="col-12 col-md-8 col-lg-6 col-xl-5">
                <div class="card py-3 px-2">

                    <div class="division">
                        <div class="row d-flex justify-content-center">
                            <div class="col-3"><div class="line l"></div></div>
                            <div class="col-6" style="width: auto; background: #ffffff; z-index: 2;"><span class="font-weight-bold" style="font-size: 15px;">Login | <?php echo $config['title'];?></span></div>
                            <div class="col-3"><div class="line r"></div></div>
                        </div>
                    </div>

                    <form class="myform" method="POST" action="">
                        <?php
                        if ($gagal){
                            echo '<span id="invalid" class="mb-1 text-danger">Username atau Password salah!</span>';
                        }
                        ?>

                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Email" name="username" required>
                          </div>
                         <div class="form-group">
                            <div class="form-input">
                                <input id="password" type="password" class="form-control" placeholder="Password" name="password" required>
                                <i class="fas fa-eye-slash" id="showpass"></i>
                            </div>

                          </div>
                          <label for="roles" class="labels text-muted mb-1">Login Sebagai</label>
                          <select class="w-100 form-control" name="roles">
                            <?php
                                $roles = explode(",", $config['roles']); // Convert the roles string to an array
                                foreach ($roles as $value) {
                                    echo '<option value="' . $value . '">' . $value . '</option>';
                                }
                            ?>
                                    </select>
                          <div class="row">
                            <div class="col-md-6 col-12 d-flex justify-content-start align-items-center bn" id="reqAcc"><i class="fas fa-chevron-left mr-1"></i>Daftar Akun</div>
                              <div class="col-md-6 col-12 d-flex justify-content-end align-items-center bn" id="forgotPass">Lupa kata sandi<i class="fa-solid fa-question ml-1"></i></div>
                          </div>

                          <div class="form-group mt-3 align-content-center">
                            <button class="btn btn-primary pickImageBtn w-100 text-uppercase" type="submit">Login</button>
                              <!--button type="button" class="btn btn-block btn-primary btn-lg" style="color: #212121;"><small><i class='bx bx-user mr-2' ></i>Login</small></button-->
                          </div>

                    </form>


                </div>
            </div>
            <div id="_forgot" style="display:none;" class="col-12 col-md-8 col-lg-6 col-xl-5">
                <div class="card py-3 px-2">
                    <div class="division">
                        <div class="row d-flex justify-content-center">
                            <div class="col-3"><div class="line l"></div></div>
                            <div class="col-6" style="width: auto; background: #ffffff; z-index: 2;"><span class="font-weight-bold">Login | <?php echo $config['title'];?></span></div>
                            <div class="col-3"><div class="line r"></div></div>
                        </div>
                    </div>
                    <div class="row d-flex justify-content-center ml-5 mr-5 mb-3">Masukkan email anda, dan kami akan mengirimkan email untuk info akun anda.</div>
                    <form class="myform" method="POST" action="">
                        <div class="form-group">
                            <input type="email" class="form-control" placeholder="Email" required>
                          </div>
                          <div class="row">
                            <div class=" d-flex justify-content-start align-items-center bn" id="back"><i class="fas fa-chevron-left mr-1"></i> Kembali</div>
                        </div>

                          <div class="form-group mt-3 align-content-center ">
                            <button class="btn btn-primary pickImageBtn w-100 text-uppercase" type="submit">Kirim</button>
                          </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</body>
</html>