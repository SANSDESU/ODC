
$(document).ready(function() {
    const showpassBtn = document.getElementById("showpass");
    const forgot = document.getElementById("forgotPass");
    const request = document.getElementById("reqAcc");
    const back = document.getElementById("back");

    showpassBtn.addEventListener('click', function() {
        showPw();
    });

    forgot.addEventListener('click', function() {
        menu('_forgot');
    });

    request.addEventListener('click', function() {
        menu('_forgot');
    });

    back.addEventListener('click', function() {
        menu('_main');
    });
});


function menu(id) {

    view = document.getElementById(id);
    main = document.getElementById("_main");
    forgot = document.getElementById("_forgot");

    main.style.display = 'none';
    forgot.style.display = 'none';

    view.style.display = 'block';

}


function showPw() {
    shpw = document.getElementById("showpass");

    var x = document.getElementById("password");
    if (x.type === "password") {
        shpw.classList.remove('fa-eye-slash');
        shpw.classList.add('fa-eye');
        x.type = "text";
    } else {
        shpw.classList.remove('fa-eye');
        shpw.classList.add('fa-eye-slash');
        x.type = "password";
    }

}




