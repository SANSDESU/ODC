<?php
session_start();
unset($_SESSION['browser']);
unset($_SESSION['ip']);
unset($_SESSION['user']);
unset($_SESSION['_token']);
unset($_SESSION['__token']);
session_regenerate_id();
session_destroy();

if(!isset($_SESSION['browser']) || !isset($_SESSION['ip']) || empty($_SESSION['user'])) {
    echo("session reset");
    exit;
}

if ($_SESSION['browser'] != md5($_SERVER['HTTP_USER_AGENT']) || $_SESSION['ip'] != $_SERVER['REMOTE_ADDR']) {
    echo("session reset");
    exit;
}