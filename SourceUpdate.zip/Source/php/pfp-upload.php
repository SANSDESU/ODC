<?php

// Check if we've uploaded a file
if( isset( $_POST[ 'UploadPFP' ] ) ) {
// Be sure we're dealing with an upload
if (is_uploaded_file($_FILES['pfpupload']['tmp_name']) === false) {
    throw new \Exception('Error on upload: Invalid file definition');
}

$pdo_user_data = include "koneksi.php";
        $query_user_data = $pdo_user_data->prepare("select nama from student where id=:id");
        $query_user_data->bindParam(':id', $_SESSION['user']['id'], PDO::PARAM_INT);
        $query_user_data->execute();
        $user_data = $query_user_data->fetch();

$img_path   = '/'.$user_data['nama'].'/';

$target_path   = '../foto/'.$user_data['nama'].'/';

// Rename the uploaded file
$uploadName = $_FILES['pfpupload']['name'];
$ext = strtolower(substr($uploadName, strripos($uploadName, '.')+1));
$filename = round(microtime(true)).mt_rand().'.'.$ext;

try {
    $pdo_update = include "koneksi.php";
    $query_upload = $pdo_update->prepare("update db_siswa set foto_profil=:foto_profil where user_id=:user_id");
    $query_upload->execute(array(
        'foto_profil' => $img_path.$filename,
        'user_id' => $_SESSION['user']['id']

    ));
    echo 'success';
}

catch(Exception $e){
    echo 'error '.$e;
}

move_uploaded_file($_FILES['pfpupload']['tmp_name'],'../foto/'.$user_data['nama'].'/'.$filename);
// Insert it into our tracking along with the original name
}


?>