<?php
include "../php/url.php";
session_start();
if(!isset($_SESSION['browser']) || !isset($_SESSION['ip']) || empty($_SESSION['user'])) {
    header("Location: ".host()."/login");
    exit;
}

if ($_SESSION['browser'] != md5($_SERVER['HTTP_USER_AGENT']) || $_SESSION['ip'] != $_SERVER['REMOTE_ADDR']) {
    header("Location: ".host()."/login");
    exit;
}
