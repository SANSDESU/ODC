<?php
$data = $_POST['dataString']; // array
$newpass = $_POST['pass'];
$major = $_POST['major'];
$category = $_POST['category'];

$category = str_replace(", ",",",$category);
//echo var_dump($data).'<br>'.$newpass.'<br>'.$major.'<br>'.$category;
$ages = date('Y',strtotime($data[6]['value']));

$age = date('Y') - $ages;
session_start();

try {
    $pdo_update = include "koneksi.php";
    $query_upload = $pdo_update->prepare("update db_siswa set nama_depan=:nama_depan, nama_belakang=:nama_belakang, tanggal_lahir=:tanggal_lahir, umur=:umur, jurusan=:jurusan, tahun_lulus=:tahun_lulus, status_pekerjaan=:status_pekerjaan, no_hp=:no_hp, email=:email, alamat=:alamat, asal_sekolah=:asal_sekolah, no_wa=:no_wa, bio=:bio, skill=:skill where user_id=:user_id");
    $query_upload->execute(array(
        'nama_depan' => $data[1]['value'],
        'nama_belakang' => $data[2]['value'],
        'tanggal_lahir' => $data[6]['value'],
        'umur' => $age,
        'jurusan' => $major,
        'tahun_lulus' => $data[7]['value'],
        'status_pekerjaan' => $data[10]['value'],
        'no_hp' => $data[9]['value'],
        'email' => $data[3]['value'],
        'alamat' => $data[4]['value'],
        'asal_sekolah' => $data[5]['value'],
        'no_wa' => $data[9]['value'],
        'bio' => $data[0]['value'],
        'skill' => $category,
        'user_id' => $_SESSION['user']['id']

    ));
    echo 'success';
}

catch(Exception $e){
    echo 'error '.$e;
}

// function gen_uid($l=5){
//     return substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"), 10, $l);
// }
// $mime_type = mime_content_type($_FILES['imglink']['tmp_name']);
// $allowed_file_types = ['image/png', 'image/jpeg'];
// if (! in_array($mime_type, $allowed_file_types)) {
//    // File type is NOT allowed.
//  echo "Only PNG and JPG images are allowed!";
//  exit;
// }
//  $uploaddir = '../uploads/images/';

//  $name = pathinfo($_FILES['imglink']['name'], PATHINFO_FILENAME);
//  $ext  = pathinfo($_FILES['imglink']['name'], PATHINFO_EXTENSION);

//  $newname = gen_uid(rand(0,30));
//  $uploadfile = $uploaddir.$newname.".webp";
//  if (move_uploaded_file($_FILES['imglink']['tmp_name'], $uploadfile)) {
//      $imglink = basename($uploadfile);
//  } else {
//      echo "Image upload failed!";
//      die();
//  }

?>