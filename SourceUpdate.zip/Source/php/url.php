<?php
function hostname($path){
    $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

    $url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

    $x = pathinfo($url);
return $x['dirname'].$path;
}
function host_name(){
    $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

    $url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

    $x = pathinfo($url);
return $x['dirname'];
}
function host(){
    $protocol = parse_url(host_name(), PHP_URL_SCHEME);
    $hostname = parse_url(host_name(), PHP_URL_HOST);
    return $protocol.'://'.$hostname;
}
?>