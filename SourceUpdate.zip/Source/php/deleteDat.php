<?php
$table = $_POST['table']; // Get the selected major from the AJAX request
$id = $_POST['id'];

$pdo = include "koneksi.php";
$query = $pdo->prepare("DELETE FROM ".$table." WHERE id=:id");
$query->bindParam(':id', $id);
$query->execute();

if (mysqli_query($conn, $sql)) {
    echo "true";
} else {
    echo "false ";
}

mysqli_close($conn);

?>