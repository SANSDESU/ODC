
<?php
function host(){
    $protocol = parse_url(host_name(), PHP_URL_SCHEME);
    $hostname = parse_url(host_name(), PHP_URL_HOST);
    return $protocol.'://'.$hostname;
}

session_start();
unset($_SESSION['browser']);
unset($_SESSION['ip']);
unset($_SESSION['user']);
session_regenerate_id();
session_destroy();

header("Location: ".host()."login");
