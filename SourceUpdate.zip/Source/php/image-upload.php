<?php
// Start the session

function uploadFile($db){

    require '../php/function.php';

    if( isset( $_POST[ 'Upload' ] ) ) {
        $csrf_failed = "
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Upload Gagal!',
                    text: 'CSRF TOKEN MATCH FAILED!',
                    showConfirmButton: true,
                    confirmButtonText: 'Tutup'
                    timer: 1500
                })
            </script>";

        // Check Anti-CSRF token
        if ($_POST['_token'] === $_SESSION['_token'])
        {

            $js_success = "
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Upload Sukses!',
                    showConfirmButton: true,
                    confirmButtonText: 'Tutup'
                    timer: 1500
                })
            </script>";

            $js_failed = "
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Upload Gagal!',
                    showConfirmButton: true,
                    confirmButtonText: 'Tutup'
                    timer: 1500
                })
            </script>";
            // File information
            $file_title = $_POST['file-title'];
            $file_date = $_POST['file-date'];
            $uploaded_name = $_FILES[ 'uploaded' ][ 'name' ];
            $uploaded_ext  = substr( $uploaded_name, strrpos( $uploaded_name, '.' ) + 1);
            $uploaded_size = $_FILES[ 'uploaded' ][ 'size' ];
            $uploaded_type = $_FILES[ 'uploaded' ][ 'type' ];
            $uploaded_tmp  = $_FILES[ 'uploaded' ][ 'tmp_name' ];

            // Where are we going to be writing to?
            $pdo_user_data = include "koneksi.php";
            $query_user_data = $pdo_user_data->prepare("select nama from ".$db." where id=:id");
            $query_user_data->bindParam(':id', $_SESSION['user']['id'], PDO::PARAM_INT);
            $query_user_data->execute();
            $user_data = $query_user_data->fetch();

            $img_path   = '/'.$user_data['nama'].'/';
            $target_path   = '../foto/'.$user_data['nama'].'/';
            $target_file   =  md5( uniqid() . $uploaded_name ) . '.' . $uploaded_ext;
            $temp_file     = ( ( ini_get( 'upload_tmp_dir' ) == '' ) ? ( sys_get_temp_dir() ) : ( ini_get( 'upload_tmp_dir' ) ) );
            $temp_file    .= DIRECTORY_SEPARATOR . md5( uniqid() . $uploaded_name ) . '.' . $uploaded_ext;


            // Is it an image?
            if( ( strtolower( $uploaded_ext ) == 'jpg' || strtolower( $uploaded_ext ) == 'jpeg' || strtolower( $uploaded_ext ) == 'png' ) &&
                ( $uploaded_size < 100000 ) &&
                ( $uploaded_type == 'image/jpeg' || $uploaded_type == 'image/png' ) &&
                getimagesize( $uploaded_tmp ) ) {



                // Strip any metadata, by re-encoding image (Note, using php-Imagick is recommended over php-GD)
                if( $uploaded_type == 'image/jpeg' ) {

                    $img = imagecreatefromjpeg( $uploaded_tmp );
                    imagejpeg( $img, $temp_file, 100);
                                }
                else {
                    $img = imagecreatefrompng( $uploaded_tmp );
                    imagepng( $img, $temp_file, 9);
                }
                imagedestroy( $img );

                // Can we move the file to the web root from the temp folder?
                if( rename( $temp_file, ( getcwd() . DIRECTORY_SEPARATOR . $target_path . $target_file ) ) ) {
                    // Yes!
                    echo $js_success;
                    $pdodt = include "../php/koneksi.php";
                    $querydt = $pdodt->prepare("select * from db_siswa where user_id=:user_id");
                    $querydt->bindParam(':user_id', $_SESSION['user']['id'], PDO::PARAM_INT);
                    $querydt->execute();
                    $datadt = $querydt->fetch();

                    $fullname = $datadt['nama_depan']." ".$datadt['nama_belakang'];

                    $pdo_upload = include "koneksi.php";
                    $query_upload = $pdo_upload->prepare("insert into db_sertifikat (user_id, pemilik, nama_sertifikat, foto_sertifikat, tanggal_diperoleh, tanggal_diupload) values(:user_id, :pemilik,:nama_sertifikat,:foto_sertifikat,:tanggal_diperoleh,:tanggal_diupload)");
                    $query_upload->execute(array(
                        'user_id' => $_SESSION['user']['id'],
                        'pemilik' => $fullname,
                        'nama_sertifikat' => $file_title,
                        'foto_sertifikat' => $img_path . $target_file,
                        'tanggal_diperoleh' => $file_date,
                        'tanggal_diupload' => date('Y-m-d')

                    ));

                    $target = getcwd() . DIRECTORY_SEPARATOR . $target_path . $target_file;
                    //echo "<pre><a href='${target_path}${target_file}'>${target_file}</a> succesfully uploaded!</pre>";

                }
                else {
                    // No
                    //echo '<pre>Your image was not uploaded.</pre>';
                    echo $js_failed;
                }

                // Delete any temp files
                if( file_exists( $temp_file ) )
                    unlink( $temp_file );
            }
            else {
                // Invalid file
                echo $js_failed;
            }

        }
        else{
            //die("CSRF TOKEN MATCH FAILED!...");
            echo $csrf_failed;
        }
    }

    generateSessionToken();

}

?>