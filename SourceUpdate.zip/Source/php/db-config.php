<?php
$pdo_config = include "koneksi.php";
$query_config = $pdo_config->prepare("select * from config");
$query_config->execute(); // Add this line to execute the query
$config = $query_config->fetch();
