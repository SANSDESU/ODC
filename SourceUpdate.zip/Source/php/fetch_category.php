<?php
$major = $_POST['major']; // Get the selected major from the AJAX request
$category = $_POST['category'];

// Fetch user's existing categories from the database or wherever you store them
// For now, I'll provide an example array
$userCategories = explode(",", $category); // Replace this with your actual data

// Fetch category data based on major from your database
// You should use prepared statements to prevent SQL injection

// Example: fetch categories for selected major
$pdo = include "koneksi.php";
$query = $pdo->prepare("SELECT kategori FROM config WHERE name = :major");
$query->bindParam(':major', $major);
$query->execute();
$catdata = $query->fetch();

// Create category items based on fetched data
$categoryItems = explode(",", $catdata['kategori']);

// Generate HTML for category options with selected attribute if user has the category
$html = '<select id="choices-multiple-remove-button" placeholder="Pilih Keahlian" multiple>';
foreach ($categoryItems as $item) {
    $selected = in_array($item, $userCategories) ? 'selected' : '';
    $html .= '<option value="' . $item . '" ' . $selected . '>' . $item . '</option>';
}
$html .= '</select>';

echo $html;
?>
