-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 08, 2023 at 05:38 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bkk_soji`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(255) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `salt` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `aktif` tinyint(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `salt`, `aktif`, `nama`, `role`) VALUES
(1, 'admin@soji', '60769dae1ca24eb7608c165f580730dd09f96c7e', 'tkjsoji', 1, 'Admin', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE `config` (
  `id` int(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `kategori` varchar(255) DEFAULT NULL,
  `roles` varchar(255) DEFAULT NULL,
  `inisial_jurusan` varchar(255) DEFAULT NULL,
  `jurusan` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`id`, `name`, `kategori`, `roles`, `inisial_jurusan`, `jurusan`, `title`) VALUES
(1, '', NULL, 'Super Admin,Admin,Guru,Industri,Siswa/Alumni', 'TKR,TPL,TEI,TKJ,PH,TB', '[TKR] Teknik Kendaraan Ringan,[TPL] Teknik Pengelasan dan Fabrikasi Logam,[TEI] Teknik Elektronika,[TKJ] Teknik Jaringan Komputer dan Telekomunikasi,[PH] Perhotelan,[TB] Kuliner', 'BKK-SOJI'),
(2, 'TKR', 'Engineering,Mechanical Engineering', NULL, NULL, NULL, NULL),
(3, 'TPL', 'Welding', NULL, NULL, NULL, NULL),
(4, 'TEI', 'Electricity,Robotics', NULL, NULL, NULL, NULL),
(5, 'TKJ', 'Networking,Programming,Design,Network Technician', NULL, NULL, NULL, NULL),
(6, 'PH', 'Housekeeping,Front Office', NULL, NULL, NULL, NULL),
(7, 'TB', 'F&B Product,F&B Service', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_sertifikat`
--

CREATE TABLE `db_sertifikat` (
  `id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `pemilik` varchar(255) NOT NULL,
  `nama_sertifikat` varchar(255) NOT NULL,
  `foto_sertifikat` varchar(255) NOT NULL,
  `tanggal_diperoleh` varchar(255) NOT NULL,
  `tanggal_diupload` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `db_sertifikat`
--

INSERT INTO `db_sertifikat` (`id`, `user_id`, `pemilik`, `nama_sertifikat`, `foto_sertifikat`, `tanggal_diperoleh`, `tanggal_diupload`) VALUES
(1, 2, 'Surya Hadini S', 'Sertifikat 1', '/Surya/serti1.jpg', '2022-12-25', '2023-08-10'),
(2, 2, 'Surya Hadini S', 'Sertifikat 2', '/Surya/serti2.jpg', '2022-12-25', '2023-08-11'),
(3, 2, 'Surya Hadini S', 'Sertifikat 3', '/Surya/serti3.jpg', '2022-12-25', '2023-08-12');

-- --------------------------------------------------------

--
-- Table structure for table `db_siswa`
--

CREATE TABLE `db_siswa` (
  `id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `nama_depan` varchar(255) NOT NULL,
  `nama_belakang` varchar(255) NOT NULL,
  `tanggal_lahir` varchar(255) NOT NULL,
  `umur` int(255) NOT NULL,
  `jurusan` varchar(255) NOT NULL,
  `tahun_lulus` int(255) NOT NULL,
  `status_pekerjaan` varchar(255) NOT NULL DEFAULT 'Belum Bekerja',
  `no_hp` decimal(65,0) NOT NULL,
  `email` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `asal_sekolah` varchar(255) NOT NULL,
  `no_wa` decimal(65,0) NOT NULL,
  `foto_profil` varchar(255) NOT NULL,
  `bio` varchar(255) NOT NULL,
  `skill` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `db_siswa`
--

INSERT INTO `db_siswa` (`id`, `user_id`, `nama_depan`, `nama_belakang`, `tanggal_lahir`, `umur`, `jurusan`, `tahun_lulus`, `status_pekerjaan`, `no_hp`, `email`, `alamat`, `asal_sekolah`, `no_wa`, `foto_profil`, `bio`, `skill`) VALUES
(1, 1, 'Siswa', 'S', '2023-08-22', 18, '[TKJ] Teknik Jaringan Komputer dan Telekomunikasi', 2024, 'Belum Bekerja', '891234567890', 'test@mail.com', 'di rumah', 'SOJI', '891234567890', '/foto/profil.png', 'tes deskripsi 123', 'gatau'),
(2, 2, 'Surya', 'HS', '2004-01-14', 19, '[TKJ] Teknik Jaringan Komputer dan Telekomunikasi', 2024, 'Bekerja', '891234567890', 'localhost@mail.com', 'ada disini', 'Soji', '891234567890', '/Surya/profil.jpg', 'Deskripsi singkat lanjut nanti', 'Design,Programming');

-- --------------------------------------------------------

--
-- Table structure for table `industry`
--

CREATE TABLE `industry` (
  `id` int(255) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `salt` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `aktif` tinyint(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `industry`
--

INSERT INTO `industry` (`id`, `username`, `password`, `salt`, `aktif`, `nama`, `role`) VALUES
(1, 'industri@soji', 'cdc4fe430852bcd3db185d10e1b31f08f32c0b39', 'tkjsoji', 1, 'Industri', 'Industri');

-- --------------------------------------------------------

--
-- Table structure for table `mail`
--

CREATE TABLE `mail` (
  `id` int(255) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `roles` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mail`
--

INSERT INTO `mail` (`id`, `kategori`, `roles`, `title`) VALUES
(1, '1', 'Super Admin,Admin,Pengawas,Industri,Siswa', 'BKK-SOJI');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(255) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `salt` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `aktif` tinyint(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `username`, `password`, `salt`, `aktif`, `nama`, `role`) VALUES
(1, 'siswa@soji', '72d080f232c3f1b5cc98dfd9a783c75ba06d5855', 'tkjsoji', 1, 'Siswa', 'Siswa'),
(2, 'surya@soji', '72d080f232c3f1b5cc98dfd9a783c75ba06d5855', 'tkjsoji', 1, 'Surya', 'Siswa');

-- --------------------------------------------------------

--
-- Table structure for table `super_admins`
--

CREATE TABLE `super_admins` (
  `id` int(255) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `salt` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `aktif` tinyint(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `super_admins`
--

INSERT INTO `super_admins` (`id`, `username`, `password`, `salt`, `aktif`, `nama`, `role`) VALUES
(1, 'super@soji', '030db90b3d04108a68ad6b36bad33d6dfe47f4c2', 'tkjsoji', 1, 'Super Admin', 'Super Admin');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` int(255) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `salt` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `aktif` tinyint(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`id`, `username`, `password`, `salt`, `aktif`, `nama`, `role`) VALUES
(1, 'guru@soji', '8709f668c0621f4e15460d64b1a236fe9cebb7a0', 'tkjsoji', 1, 'Guru', 'Guru');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `db_sertifikat`
--
ALTER TABLE `db_sertifikat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_siswa`
--
ALTER TABLE `db_siswa`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `industry`
--
ALTER TABLE `industry`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `mail`
--
ALTER TABLE `mail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `super_admins`
--
ALTER TABLE `super_admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `config`
--
ALTER TABLE `config`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `db_sertifikat`
--
ALTER TABLE `db_sertifikat`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `db_siswa`
--
ALTER TABLE `db_siswa`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `industry`
--
ALTER TABLE `industry`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mail`
--
ALTER TABLE `mail`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `super_admins`
--
ALTER TABLE `super_admins`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
